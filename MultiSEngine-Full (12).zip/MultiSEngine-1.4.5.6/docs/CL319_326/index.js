/**
 * CL319_326 v0.3.5
 * After 0.3.4: -999 gone, still ends at -247. Widen death clamp:
 * any negative int16/int32 in the life tail of NPCUpdate → 0.
 * Positive HP untouched.
 */
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { createRequire } from "module";
import PacketWriter from "@popstarfreas/packetfactory/packetwriter";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

const TARGET = (() => {
  try {
    const t = fs.readFileSync(path.join(__dirname, "target.txt"), "utf8").trim();
    if (t.startsWith("Terraria")) return t;
  } catch {}
  return "Terraria319";
})();

const RAW = new Set([
  17, 19, 20, 48, 63, 64, 79, 125,
  21, 22, 39, 88, 90, 145, 148, 151, 160,
  27, 29,
  23, 24, 28, 153, 162,
  26, 117, 118,
  5, 138,
]);
const NEVER_RAW = new Set([82]);

function typeByte(data) {
  try {
    if (!data || data.length < 3) return -1;
    return data[2] | 0;
  } catch {
    return -1;
  }
}
function readVersion(buf) {
  try {
    if (!buf || buf.length < 4) return null;
    let i = 3, strLen = 0, shift = 0;
    while (i < buf.length) {
      const b = buf[i++];
      strLen |= (b & 0x7f) << shift;
      if ((b & 0x80) === 0) break;
      shift += 7;
      if (shift > 28) return null;
    }
    if (i + strLen > buf.length) return null;
    return Buffer.from(buf).subarray(i, i + strLen).toString("utf8");
  } catch {
    return null;
  }
}
function proto(ver) {
  const m = (ver || "").match(/Terraria(\d+)/i);
  return m ? parseInt(m[1], 10) : 0;
}
function dropCache(client) {
  if (!client._clDrops) client._clDrops = new Map();
  return client._clDrops;
}
function cacheItemDrop(client, data) {
  try {
    if (!data || data.length < 15) return;
    const itemId = data.readInt16LE(3);
    const x = data.readFloatLE(5);
    const y = data.readFloatLE(9);
    if (Number.isFinite(x) && Number.isFinite(y)) dropCache(client).set(itemId, { x, y });
  } catch {}
}

function itemOwnerTo326(data, client) {
  try {
    if (!data || data[2] !== 22) return data;
    if (data.length === 17) {
      try {
        const id = data.readInt16LE(3);
        const x = data.readFloatLE(9);
        const y = data.readFloatLE(13);
        if (Number.isFinite(x) && Number.isFinite(y)) dropCache(client).set(id, { x, y });
      } catch {}
      return data;
    }
    if (data.length === 14) {
      const id = data.readInt16LE(3);
      const owner = data[5];
      const x = data.readFloatLE(6);
      const y = data.readFloatLE(10);
      dropCache(client).set(id, { x, y });
      const out = Buffer.alloc(17);
      out.writeUInt16LE(17, 0);
      out[2] = 22;
      out.writeInt16LE(id, 3);
      out[5] = owner;
      out[6] = 0;
      out.writeUInt16LE(0, 7);
      out.writeFloatLE(x, 9);
      out.writeFloatLE(y, 13);
      return out;
    }
    if (data.length >= 6 && data.length < 14) {
      const id = data.readInt16LE(3);
      const owner = data.length > 5 ? data[5] : 255;
      const pos = dropCache(client).get(id);
      if (!pos) return data;
      const out = Buffer.alloc(17);
      out.writeUInt16LE(17, 0);
      out[2] = 22;
      out.writeInt16LE(id, 3);
      out[5] = owner;
      out[6] = 0;
      out.writeUInt16LE(0, 7);
      out.writeFloatLE(pos.x, 9);
      out.writeFloatLE(pos.y, 13);
      return out;
    }
  } catch {}
  return data;
}

function destroyProjTo319(data) {
  try {
    if (!data || data[2] !== 29 || data.length <= 6) return data;
    const out = Buffer.alloc(6);
    out.writeUInt16LE(6, 0);
    out[2] = 29;
    out[3] = data[3];
    out[4] = data[4];
    out[5] = data[5];
    return out;
  } catch {
    return data;
  }
}

/**
 * Wider death clamp than 0.3.4:
 * - whole payload: int16 == -999 → 0
 * - last 20 bytes: any int16 < 0 → 0 (catches -247 etc.)
 * - last 20 bytes: int32 in (-500000,-1) → 0
 * Never touch positive values.
 */
function npcUpdateDeathFix(data) {
  try {
    if (!data || data[2] !== 23 || data.length < 16) return data;
    const buf = Buffer.from(data);
    let changed = false;

    for (let off = 3; off + 2 <= buf.length; off++) {
      if (buf.readInt16LE(off) === -999) {
        buf.writeInt16LE(0, off);
        changed = true;
      }
    }

    const tailStart = Math.max(3, buf.length - 20);
    for (let off = tailStart; off + 2 <= buf.length; off++) {
      const v = buf.readInt16LE(off);
      if (v < 0) {
        buf.writeInt16LE(0, off);
        changed = true;
      }
    }
    for (let off = tailStart; off + 4 <= buf.length; off++) {
      const v = buf.readInt32LE(off);
      if (v < 0 && v > -500000) {
        buf.writeInt32LE(0, off);
        changed = true;
      }
    }

    if (changed) {
      buf.writeUInt16LE(buf.length, 0);
      return buf;
    }
  } catch {}
  return data;
}

function touchNpcTracking(server, data) {
  try {
    if (!server?.entityTracking || !data || data.length < 4) return;
    if (!server.entityTracking.npcs) server.entityTracking.npcs = [];
    const slot = data[3];
    if (slot >= 0 && slot < 256) {
      if (!server.entityTracking.npcs[slot]) server.entityTracking.npcs[slot] = { active: true };
      else server.entityTracking.npcs[slot].active = true;
    }
  } catch {}
}

function onServerToClient(server, client, data) {
  const t = typeByte(data);
  if (t === 23) {
    touchNpcTracking(server, data);
    return npcUpdateDeathFix(data);
  }
  if (t === 21 || t === 90) cacheItemDrop(client, data);
  if (t === 22) return itemOwnerTo326(data, client);
  if (t === 151) {
    try {
      if (data.length >= 5) dropCache(client).delete(data.readInt16LE(3));
    } catch {}
  }
  return data;
}

function onClientToServer(server, data) {
  const t = typeByte(data);
  if (t === 29) return destroyProjTo319(data);
  if (t === 28 || t === 24) touchNpcTracking(server, data);
  return data;
}

function patchHandlers(logging) {
  let okC = false, okS = false;
  const clientPath = path.resolve(__dirname, "../../dimensions/clientpackethandler.js");
  const serverPath = path.resolve(__dirname, "../../dimensions/terrariaserverpackethandler.js");

  try {
    if (fs.existsSync(clientPath)) {
      const CPH = require(clientPath).default || require(clientPath);
      if (CPH?.prototype?.handlePacket && !CPH.prototype.__cl319_326_v35) {
        const orig = CPH.prototype.handlePacket;
        CPH.prototype.handlePacket = function (client, rawPacket) {
          try {
            let data = rawPacket?.data;
            const t = typeByte(data);
            if (t === 1) {
              const real = readVersion(data) || "unknown";
              if (proto(real) > 319) {
                client._clBridge = true;
                client._clRealVersion = real;
              }
              try {
                rawPacket.data = new PacketWriter().setType(1).packString(TARGET).data;
                client.version = TARGET;
              } catch (e) {
                logging.error(`[CL319_326] rewrite: ${e?.message || e}`);
              }
              logging.info(
                `[CL319_326] connect seen="${real}" bridge=${!!client._clBridge} → ${TARGET}`
              );
              return orig.call(this, client, rawPacket);
            }
            if (client._clBridge && RAW.has(t) && !NEVER_RAW.has(t)) {
              const server = client?.server;
              data = onClientToServer(server, data);
              if (server?.sendDirect && data) {
                server.sendDirect(Buffer.isBuffer(data) ? data : Buffer.from(data));
                return null;
              }
              return null;
            }
          } catch (e) {
            logging.error(`[CL319_326] client: ${e?.message || e}`);
          }
          return orig.call(this, client, rawPacket);
        };
        CPH.prototype.__cl319_326_v35 = true;
        okC = true;
      }
    }
  } catch (e) {
    logging.error(`[CL319_326] client patch: ${e?.message || e}`);
  }

  try {
    if (fs.existsSync(serverPath)) {
      const SPH = require(serverPath).default || require(serverPath);
      if (SPH?.prototype?.handlePacket && !SPH.prototype.__cl319_326_v35) {
        const orig = SPH.prototype.handlePacket;
        SPH.prototype.handlePacket = function (server, packet, source) {
          try {
            const client = server?.client;
            if (client?._clBridge && packet?.data) {
              const t = typeByte(packet.data);
              if (RAW.has(t) && !NEVER_RAW.has(t)) {
                return onServerToClient(server, client, packet.data);
              }
            }
          } catch (e) {
            logging.error(`[CL319_326] server: ${e?.message || e}`);
          }
          return orig.call(this, server, packet, source);
        };
        SPH.prototype.__cl319_326_v35 = true;
        okS = true;
      }
    }
  } catch (e) {
    logging.error(`[CL319_326] server patch: ${e?.message || e}`);
  }
  logging.info(
    `[CL319_326] v0.3.5 target=${TARGET} c=${okC} s=${okS} death clamp any negative tail`
  );
  return { okC, okS };
}

class CL319_326 {
  constructor(logging) {
    this.name = "CL319_326";
    this.version = "0.3.5";
    this.logging = logging;
    patchHandlers(logging);
  }
}
export default CL319_326;
