using System.Collections.Concurrent;
using System.Net.Sockets;
using System.Text.Json;
using MultiSEngine;
using MultiSEngine.Core;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MSE.Warps;

/// <summary>
/// Warp plates plugin (Dimensions-style). Config: Plugins/warps.json (separate from main Config.json).
/// </summary>
public class WarpsPlugin : IMSEPlugin
{
    public string Name => "Warps";
    public string Description => "Warp plates — config in Plugins/warps.json";
    public string Author => "MultiSEngine";
    public Version Version => new(1, 1, 0);

    public class WarpDef
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float W { get; set; } = 4;
        public float H { get; set; } = 4;
        public string Target { get; set; } = "";
        public string OnlyOnServer { get; set; } = "";
    }

    public class WarpConfig
    {
        public string OnlyOnServer { get; set; } = "Server1";
        public int CountdownSeconds { get; set; } = 3;
        public int CooldownSeconds { get; set; } = 6;
        public List<WarpDef> Warps { get; set; } = new();
    }

    class Active
    {
        public WarpDef Warp = null!;
        public bool Cancelled;
        public CancellationTokenSource Cts = new();
    }

    static WarpConfig Cfg = new();
    static readonly ConcurrentDictionary<ClientData, Active> ActiveWarps = new();
    static readonly ConcurrentDictionary<ClientData, long> Cooldowns = new();
    static string ConfigPath = "";

    public void Initialize()
    {
        var dir = Path.Combine(AppContext.BaseDirectory, "Plugins");
        Directory.CreateDirectory(dir);
        ConfigPath = Path.Combine(dir, "warps.json");
        LoadConfig();
        Hooks.PlayerUpdate += OnPlayerUpdate;
        Logs.Info($"[Warps] loaded — {Cfg.Warps.Count} plate(s), config={ConfigPath}");
    }

    public void Dispose() => Hooks.PlayerUpdate -= OnPlayerUpdate;

    static void LoadConfig()
    {
        try
        {
            if (!File.Exists(ConfigPath))
            {
                Cfg = new WarpConfig
                {
                    OnlyOnServer = "Server1",
                    CountdownSeconds = 3,
                    CooldownSeconds = 6,
                    Warps =
                    [
                        new() { X = 4171, Y = 357, W = 4, H = 4, Target = "Server2", OnlyOnServer = "Server1" },
                        new() { X = 4209, Y = 357, W = 4, H = 4, Target = "Server1", OnlyOnServer = "Server2" }
                    ]
                };
                File.WriteAllText(ConfigPath, JsonSerializer.Serialize(Cfg, new JsonSerializerOptions { WriteIndented = true }));
                Logs.Info($"[Warps] created default {ConfigPath}");
                return;
            }
            Cfg = JsonSerializer.Deserialize<WarpConfig>(File.ReadAllText(ConfigPath)) ?? new();
            Cfg.Warps ??= new();
        }
        catch (Exception ex)
        {
            Logs.Warn($"[Warps] config: {ex.Message}");
            Cfg = new();
        }
    }

    static void OnPlayerUpdate(ClientData client, ReadOnlyMemory<byte> memory)
    {
        try { Handle(client, memory.Span); }
        catch (Exception ex) { Logs.Warn($"[Warps] {ex.Message}"); }
    }

    static void Handle(ClientData client, ReadOnlySpan<byte> frame)
    {
        if (client is null || client.Disposed) return;
        if (Cfg.Warps.Count == 0) return;
        if (client.State != ClientState.InGame) return;
        if (client.CurrentServer is null) return;
        if (frame.Length < 17) return;

        var cur = client.CurrentServer.Name;
        if (!string.IsNullOrEmpty(Cfg.OnlyOnServer) &&
            !cur.Equals(Cfg.OnlyOnServer, StringComparison.OrdinalIgnoreCase))
            return;

        float px = BitConverter.ToSingle(frame.Slice(9, 4));
        float py = BitConverter.ToSingle(frame.Slice(13, 4));

        if (ActiveWarps.TryGetValue(client, out var act))
        {
            if (!Contains(act.Warp, px, py))
            {
                act.Cancelled = true;
                try { act.Cts.Cancel(); } catch { }
                ActiveWarps.TryRemove(client, out _);
                _ = client.SendMessageAsync(
                    "[i:4076][c/d62ef0:[Dimensions]] [c/f88efa:Teleport cancelled (left the plate).]",
                    Utils.MakeColor(255, 100, 100), false);
            }
            return;
        }

        if (client.State is ClientState.Switching or ClientState.ReadyToSwitch) return;

        long now = Environment.TickCount64;
        if (Cooldowns.TryGetValue(client, out var cd) && now - cd < Cfg.CooldownSeconds * 1000L)
            return;

        foreach (var w in Cfg.Warps)
        {
            if (!string.IsNullOrEmpty(w.OnlyOnServer) &&
                !cur.Equals(w.OnlyOnServer, StringComparison.OrdinalIgnoreCase))
                continue;
            if (!Contains(w, px, py)) continue;

            Cooldowns[client] = now;
            var active = new Active { Warp = w };
            ActiveWarps[client] = active;
            Logs.Info($"[Warps] {client.Name} → {w.Target}");
            _ = CountdownAsync(client, active);
            break;
        }
    }

    static bool Contains(WarpDef w, float px, float py)
    {
        float tx = px / 16f, ty = py / 16f;
        return w.X <= tx && tx <= w.X + w.W && w.Y <= ty && ty <= w.Y + w.H;
    }

    static async Task CountdownAsync(ClientData client, Active act)
    {
        try
        {
            int sec = Math.Max(1, Cfg.CountdownSeconds);
            for (int s = sec; s >= 1; s--)
            {
                if (client.Disposed || act.Cancelled) return;
                await client.SendMessageAsync(
                    $"[i:4076][c/d62ef0:[Dimensions]] [c/8efad2:Teleport to] {act.Warp.Target} [c/8efad2:in {s}...]",
                    Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                await Task.Delay(1000, act.Cts.Token).ConfigureAwait(false);
            }
            if (client.Disposed || act.Cancelled) return;
            ActiveWarps.TryRemove(client, out _);

            var target = Utils.GetSingleServerInfoByName(act.Warp.Target)
                ?? Config.Instance.Servers.FirstOrDefault(s =>
                    s.Name.Equals(act.Warp.Target, StringComparison.OrdinalIgnoreCase));
            if (target is null)
            {
                await client.SendMessageAsync(
                    "[i:4076][c/d62ef0:[Dimensions]] [c/FF5555:Dimension not found.]",
                    Utils.MakeColor(255, 80, 80), false).ConfigureAwait(false);
                return;
            }
            if (!await IsAliveAsync(target.IP, target.Port).ConfigureAwait(false))
            {
                await client.SendMessageAsync(
                    "[i:4076][c/d62ef0:[Dimensions]] [c/FF5555:Server temporarily unavailable.]",
                    Utils.MakeColor(255, 80, 80), false).ConfigureAwait(false);
                return;
            }
            await client.Join(target).ConfigureAwait(false);
        }
        catch (OperationCanceledException) { }
        catch (Exception ex) { Logs.Warn($"[Warps] {ex.Message}"); }
        finally { ActiveWarps.TryRemove(client, out _); }
    }

    static async Task<bool> IsAliveAsync(string host, int port)
    {
        try
        {
            using var tcp = new TcpClient();
            using var cts = new CancellationTokenSource(2000);
            await tcp.ConnectAsync(host, port, cts.Token).ConfigureAwait(false);
            return true;
        }
        catch { return false; }
    }
}
