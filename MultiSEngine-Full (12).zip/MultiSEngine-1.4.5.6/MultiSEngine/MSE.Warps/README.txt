MSE.Warps plugin
================
1. Build MultiSEngine (Release)
2. Build this plugin:
     cd MSE.Warps
     dotnet build -c Release
   DLL copies to ..\Plugins\MSE.Warps.dll automatically.

3. Config.json example:
   "WarpOnlyOnServer": "Server1",
   "WarpCountdownSeconds": 3,
   "WarpCooldownSeconds": 6,
   "Warps": [
     { "X": 4171, "Y": 357, "W": 4, "H": 4, "Target": "Server2", "OnlyOnServer": "Server1" }
   ]
