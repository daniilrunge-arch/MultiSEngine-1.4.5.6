using System.Linq;
using MultiSEngine.Core.Adapter;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MultiSEngine.Core.Handler
{
    public class PlayerInfoHandler : BaseHandler
    {
        public PlayerInfoHandler(BaseAdapter parent) : base(parent)
        {
        }
        public override async ValueTask<bool> RecieveClientDataAsync(HandlerPacketContext context)
        {
            var msgType = context.MessageId;
            switch (msgType)
            {
                case MessageID.SyncPlayer:
                    if (context.Packet is not SyncPlayer syncPlayer) throw new Exception("[PlayerInfoHandler] SyncPlayer packet not found");
                    // struct packet
                    Client.Player.RawSyncPlayer = context.Data.ToArray();
                    // Fallback: recover name from raw bytes if TrProtocol left it empty (1.4.5 voice fields)
                    if (string.IsNullOrEmpty(syncPlayer.Name))
                    {
                        var rawName = Utils.TryExtractPlayerName(context.Data.Span);
                        if (!string.IsNullOrEmpty(rawName))
                            syncPlayer.Name = rawName;
                    }
                    // Allow first name assignment (passthrough join). Only block real rename after name is set.
                    if (Client.State >= ClientState.SyncData
                        && !string.IsNullOrEmpty(Client.Name)
                        && !string.IsNullOrEmpty(syncPlayer.Name)
                        && !string.Equals(syncPlayer.Name, Client.Name, StringComparison.Ordinal))
                    {
                        await Client.DisconnectAsync("You cannot change your name.");
                        return true;
                    }
                    Client.Player.UpdateData(syncPlayer, true);
                        if (!string.IsNullOrEmpty(syncPlayer.Name) && Client.State < ClientState.InGame)
                        {
                            Logs.Info($"[{syncPlayer.Name}] connected from {Client.IP}");
                        }
                            try { MultiSEngine.Modules.Cmds.PlayerCommand.Touch(Client); } catch { }
                        // Proxy-wide unique name (cannot be on Server1 and Server2 with same nick)
                        if (!string.IsNullOrEmpty(syncPlayer.Name))
                        {
                            var dup = Data.Clients.FirstOrDefault(c =>
                                c != Client && !c.Disposed &&
                                !string.IsNullOrEmpty(c.Name) &&
                                c.Name.Equals(syncPlayer.Name, StringComparison.OrdinalIgnoreCase));
                            if (dup is not null)
                            {
                                await Client.DisconnectAsync($"Player '{syncPlayer.Name}' is already online on {dup.CurrentServer?.Name ?? "proxy"}.");
                                return true;
                            }
                        }
                    break;
                case MessageID.SyncEquipment:
                    if (context.Packet is SyncEquipment eq)
                    {
                        Client.Player.UpdateData(eq, true);
                        Client.Player.RawInventory[eq.ItemSlot] = context.Data.ToArray();
                    }
                    break;
                case MessageID.PlayerHealth:
                    Client.Player.RawPlayerHealth = context.Data.ToArray();
                    if (context.Packet is { } hpPkt)
                        Client.Player.UpdateData(hpPkt, true);
                    break;
                case MessageID.PlayerMana:
                    Client.Player.RawPlayerMana = context.Data.ToArray();
                    if (context.Packet is { } manaPkt)
                        Client.Player.UpdateData(manaPkt, true);
                    break;
                case MessageID.PlayerBuffs:
                    Client.Player.RawPlayerBuffs = context.Data.ToArray();
                    if (context.Packet is { } buffPkt)
                        Client.Player.UpdateData(buffPkt, true);
                    break;
                case MessageID.PlayerControls:
                    if (context.Packet is { } ctrlPkt)
                        Client.Player.UpdateData(ctrlPkt, true);
                    break;
                case MessageID.ClientUUID:
                    if (context.Packet is not ClientUUID uuid) throw new Exception("[PlayerInfoHandler] ClientUUID packet not found");
                    // struct packet
                    Client.Player.RawClientUUID = context.Data.ToArray();
                    if (Client.State >= ClientState.SyncData
                        && !string.IsNullOrEmpty(Client.Player.UUID)
                        && uuid.UUID != Client.Player.UUID)
                    {
                        await Client.DisconnectAsync("You cannot change your UUID.");
                        return true;
                    }
                    Client.Player.UUID = uuid.UUID;
                    return false;
            }
            return false;
        }
        public override ValueTask<bool> RecieveServerDataAsync(HandlerPacketContext context)
        {
            var msgType = context.MessageId;
            switch (msgType)
            {
                case MessageID.LoadPlayer:
                    if (context.Packet is not LoadPlayer slot) throw new Exception("[PlayerInfoHandler] LoadPlayer packet not found");
                    // struct packet
                    if (Client.Player.Index != slot.PlayerSlot)
                        Logs.Text($"Update the index of [{Client.Name}]: {Client.Player.Index} => {slot.PlayerSlot}.");
                    Client.Player.Index = slot.PlayerSlot;
                    return ValueTask.FromResult(false);
                case MessageID.WorldData:
                    if (context.Packet is not WorldData worldData) throw new Exception("[PlayerInfoHandler] WorldData packet not found");
                    // struct packet
                    Client.Player.UpdateData(worldData, false);
                    return ValueTask.FromResult(false);
                case MessageID.SpawnPlayer:
                    if (context.Packet is not SpawnPlayer spawn) throw new Exception("[PlayerInfoHandler] SpawnPlayer packet not found");
                    // struct packet
                    Client.Player.SpawnX = spawn.Position.X;
                    Client.Player.SpawnY = spawn.Position.Y;
                    Client.Player.DeathsPVE = spawn.DeathsPVE;
                    Client.Player.DeathsPVP = spawn.DeathsPVP;
                    Client.Player.Timer = spawn.Timer;
                    Client.Player.Context = spawn.Context;
                    return ValueTask.FromResult(false);
                case MessageID.FinishedConnectingToServer:
                    Client.State = ClientState.InGame;
                    Client.ArmItemTeleportSuppress(8000);
                    Logs.Success($"[{Client.Name}] InGame on {Client.CurrentServer?.Name}");
                    return ValueTask.FromResult(false);
            }
            return ValueTask.FromResult(false);
        }
    }
}
