using MultiSEngine.Core.Adapter;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;
using Terraria.Localization;
using TrProtocol.NetPackets.Modules;

namespace MultiSEngine.Core.Handler
{
    public class ChatHandler(BaseAdapter parent) : BaseHandler(parent)
    {
        // Only these are eaten by the proxy (rest go to TShock, including /spawn)
        static readonly HashSet<string> ProxyCmds = new(StringComparer.OrdinalIgnoreCase)
        {
            "/server", "/s", "/mse", "/join", "/dim", "/move",
            "/who", "/list", "/online", "/players",
            "/ping", "/servers", "/dims", "/player", "/play"
        };

        static bool IsProxyCommand(string content)
        {
            if (string.IsNullOrEmpty(content) || content[0] != '/') return false;
            var sp = content.IndexOf(' ');
            var cmd = (sp < 0 ? content : content[..sp]).Trim();
            return ProxyCmds.Contains(cmd);
        }

        public override async ValueTask<bool> RecieveClientDataAsync(HandlerPacketContext context)
        {
            if (context.MessageId != MessageID.NetModules)
                return false;

            if (context.Packet is not NetTextModule mod || mod.TextC2S is null)
                return false;

            var text = mod.TextC2S;
            if (Hooks.OnChat(Client, mod, out _))
                return true;

            var content = (text.Text ?? "").Trim();
            if (!string.IsNullOrEmpty(text.Command) && text.Command != "Say" && !content.StartsWith('/'))
                content = "/" + text.Command + (string.IsNullOrEmpty(content) ? "" : " " + content);


            if (IsProxyCommand(content))
            {
                var (handled, _) = await Command.HandleCommand(Client, content, fromConsole: false).ConfigureAwait(false);
                if (handled)
                    return true;
            }

            // Cross-server chat (normal messages only)
            if (Config.Instance.EnableChatForward && !content.StartsWith('/'))
            {
                var msg = Config.Instance.ChatFormat
                    .Replace("{servername}", Client.CurrentServer?.Name ?? "Lobby")
                    .Replace("{username}", Client.Name ?? "?")
                    .Replace("{message}", content);
                foreach (var c in Data.Clients.Where(c => c != Client && c.CurrentServer != Client.CurrentServer && !c.Disposed))
                    await c.SendMessageAsync(msg, Utils.MakeColor(200, 200, 255), false).ConfigureAwait(false);
            }

            if (Client.CurrentServer is null)
            {
                await SendToClientDirectAsync(new NetTextModule
                {
                    TextS2C = new TextS2C
                    {
                        Text = Utils.MakeLiteral(content),
                        PlayerSlot = Client.Index,
                        Color = Utils.MakeColor(255, 255, 255),
                    }
                }).ConfigureAwait(false);
                return true;
            }

            return false; // forward /spawn and other TShock cmds
        }

        string? _lastServerChat;
        long _lastServerChatTick;

        public override async ValueTask<bool> RecieveServerDataAsync(HandlerPacketContext context)
        {
            // Deduplicate identical login/greet lines TShock may emit twice on dimension switch
            if (context.MessageId != MessageID.NetModules)
                return false;
            if (context.Packet is not NetTextModule mod || mod.TextS2C is null)
                return false;
            try
            {
                var text = mod.TextS2C.Text?.ToString() ?? "";
                if (string.IsNullOrEmpty(text))
                    return false;
                var now = Environment.TickCount64;
                if (text == _lastServerChat && now - _lastServerChatTick < 2500)
                {
                    Logs.Info($"[{Client.Name}] suppressed duplicate chat");
                    return true; // eat duplicate
                }
                _lastServerChat = text;
                _lastServerChatTick = now;
            }
            catch { }
            return false;
        }
    }
}
