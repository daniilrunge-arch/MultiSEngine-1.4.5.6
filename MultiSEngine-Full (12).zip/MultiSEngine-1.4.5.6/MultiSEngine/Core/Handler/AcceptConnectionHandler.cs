using System.Buffers.Binary;
using System.Net.Sockets;
using MultiSEngine.Core.Adapter;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MultiSEngine.Core.Handler
{
    /// <summary>
    /// Dimensions-style accept:
    /// If SwitchToDefaultServerOnJoin: connect backend immediately, pure passthrough.
    /// Else: FakeWorld lobby then optional switch.
    /// </summary>
    public sealed class AcceptConnectionHandler(BaseAdapter parent) : BaseHandler(parent)
    {
        public const int Width = 8400;
        public const int Height = 2400;
        public bool IsEntered { get; private set; }
        private bool _passthroughStarted;

        public override async ValueTask<bool> RecieveClientDataAsync(HandlerPacketContext context)
        {
            var msgType = context.MessageId;
            var data = context.Data;
            switch (msgType)
            {
                case MessageID.ClientHello:
                    {
                        if (context.Packet is not ClientHello hello) return true;
                        if (!Hooks.OnPlayerJoin(Client, Client.IP, Client.Port, hello.Version, out var joinEvent))
                        {
                            Client.ReadVersion(joinEvent.Version);
                            var ver = Client.Player.VersionNum;
                            var minV = Config.Instance.MinClientVersion > 0 ? Config.Instance.MinClientVersion : 269;
                            var maxV = Config.Instance.MaxClientVersion;
                            var versionOk = ver >= minV
                                && (maxV <= 0 || ver <= maxV)
                                && (Config.Instance.EnableCrossplayFeature || ver == Config.Instance.ServerVersion);
                            if (!versionOk)
                            {
                                await Client.DisconnectAsync(Localization.Instance["Prompt_VersionNotAllowed", $"{Data.Convert(ver)} ({ver})"]);
                                return true;
                            }
                            Logs.Info($"[{Client.Name}] client protocol {Data.Convert(ver)}<{ver}> (proxy expects backend {Data.Convert(Config.Instance.ServerVersion)}<{Config.Instance.ServerVersion}>)");

                            // ===== Dimensions pure passthrough first join =====
                            if (Config.Instance.SwitchToDefaultServerOnJoin && Config.Instance.DefaultServerInternal is { } srv)
                            {
                                if (_passthroughStarted) return true;
                                _passthroughStarted = true;
                                Parent.DeregisterHandler(this);
                                if (!Data.Clients.Contains(Client))
                                    Data.Clients.Add(Client);

                                Logs.Info($"[{Client.Name}] Dimensions passthrough → {srv.Name}");
                                var ok = await Client.ConnectPassthroughAsync(srv).ConfigureAwait(false);
                                if (!ok)
                                {
                                    await Client.DisconnectAsync($"Cannot connect to {srv.Name}").ConfigureAwait(false);
                                    return true;
                                }
                                // FAKE VERSION: rewrite ClientHello to backend protocol so 1.4.5.8 client can join 1.4.5.6 server
                                var backendVer = (srv.VersionNum is > 0 and < 65535)
                                    ? srv.VersionNum
                                    : Config.Instance.ServerVersion;
                                if (Config.Instance.FakeVersionToBackend && ver != backendVer)
                                {
                                    var fakeHello = new ClientHello { Version = $"Terraria{backendVer}" };
                                    await Parent.SendToServerDirectAsync(fakeHello).ConfigureAwait(false);
                                    Logs.Info($"[{Client.Name}] FakeVersion ClientHello Terraria{ver} → Terraria{backendVer}");
                                }
                                else
                                {
                                    await Parent.SendToServerDirectAsync(context.Data).ConfigureAwait(false);
                                }
                                Client.State = ClientState.NewConnection;
                                Client.ArmItemTeleportSuppress(8000);
                                Logs.Success($"[{Client.Name}] linked to {srv.Name} (passthrough)");
                                return true;
                            }

                            // Classic FakeWorld path
                            await SendToClientDirectAsync(new LoadPlayer { PlayerSlot = 0, ServerWantsToRunCheckBytesInClientLoopThread = true }).ConfigureAwait(false);
                        }
                        return true;
                    }
                case MessageID.RequestWorldInfo:
                    {
                        var bb = new BitsByte();
                        bb[6] = true;
                        var worldData = new WorldData
                        {
                            MaxTileX = (short)Width,
                            MaxTileY = (short)Height,
                            SpawnX = (short)(Width / 2),
                            SpawnY = (short)(Height / 2),
                            WorldSurface = 0,
                            RockLayer = 0,
                            WorldName = Config.Instance.ServerName,
                            WorldUniqueID = Guid.Empty,
                            EventInfo1 = bb,
                            GameMode = 0,
                        };
                        Client.Player.OriginCharacter.WorldData = worldData;
                        await SendToClientDirectAsync(Client.Player.OriginCharacter.WorldData).ConfigureAwait(false);
                        return true;
                    }
                case MessageID.RequestTileData:
                    await SendToClientDirectAsync(Data.SpawnSquarePacket).ConfigureAwait(false);
                    await SendToClientDirectAsync(new StartPlaying()).ConfigureAwait(false);
                    return true;
                case MessageID.SpawnPlayer:
                    Parent.DeregisterHandler(this);
                    if (!Data.Clients.Contains(Client))
                        Data.Clients.Add(Client);

                    var span = data.Span;
                    Client.Player.SpawnX = BinaryPrimitives.ReadInt16LittleEndian(span[4..6]);
                    Client.Player.SpawnY = BinaryPrimitives.ReadInt16LittleEndian(span[6..8]);
                    await SendToClientDirectAsync(new FinishedConnectingToServer()).ConfigureAwait(false);
                    await Client.SendMessageAsync(Data.Motd, Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);

                    foreach (var c in Data.Clients.Where(c => c.CurrentServer is null && c != Client))
                        await c.SendMessageAsync($"{Client.Name} has join.", Utils.MakeColor(255, 255, 255), true).ConfigureAwait(false);

                    Client.ArmItemTeleportSuppress(10000);
                    Logs.Info($"[{Client.Name}] has join (FakeWorld).");
                    if (Config.Instance.SwitchToDefaultServerOnJoin)
                    {
                        if (Config.Instance.DefaultServerInternal is { })
                        {
                            await Client.SendMessageAsync(Localization.Instance["Command_Switch", Config.Instance.DefaultServerInternal.Name], Utils.MakeColor(220, 220, 130)).ConfigureAwait(false);
                            await Client.Join(Config.Instance.DefaultServerInternal).ConfigureAwait(false);
                        }
                        else
                            await Client.SendMessageAsync(Localization.Instance["Prompt_DefaultServerNotFound", [Config.Instance.DefaultServer]], Utils.MakeColor(220, 220, 130)).ConfigureAwait(false);
                    }
                    else
                        Logs.Text($"[{Client.Name}] is temporarily in FakeWorld");
                    return true;
            }
            return false;
        }
    }
}
