using System.Linq;
using MultiSEngine.Core.Adapter;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MultiSEngine.Core.Handler
{
    /// <summary>
    /// Dimensions-style switch without synthetic NPC/item/pylon packets
    /// (those desync the client and break tiles/combat).
    /// Only clears other players; client reloads world via LoadPlayer + GetSection.
    /// </summary>
    public class PreConnectHandler(BaseAdapter parent, ServerInfo server) : BaseHandler(parent)
    {
        public short SpawnX { get; private set; } = -1;
        public short SpawnY { get; private set; } = -1;
        public WorldData? World { get; private set; }

        public ServerInfo TargetServer { get; init; } = server;
        public bool IsConnecting { get; private set; } = true;

        private byte index = 0;
        private readonly TaskCompletionSource<bool> _tcs = new(TaskCreationOptions.RunContinuationsAsynchronously);
        private int _tilePacketsForwarded = 0;
        private bool _sectionSent = false;
        private bool _spawnSent = false;
        private bool _finishScheduled = false;
        private bool _cleared = false;

        public Task<bool> ConnectionTask => _tcs.Task;

        private static byte[] BuildGetSection(int x = -1, int y = -1)
        {
            var buf = new byte[12];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), 12);
            buf[2] = 8;
            System.Buffers.Binary.BinaryPrimitives.WriteInt32LittleEndian(buf.AsSpan(3, 4), x);
            System.Buffers.Binary.BinaryPrimitives.WriteInt32LittleEndian(buf.AsSpan(7, 4), y);
            buf[11] = 0;
            return buf;
        }

        private static byte[] BuildSpawnPlayer(byte slot, short sx, short sy)
        {
            var body = new byte[18];
            body[0] = 12;
            body[1] = slot;
            System.Buffers.Binary.BinaryPrimitives.WriteInt32LittleEndian(body.AsSpan(2, 4), sx);
            System.Buffers.Binary.BinaryPrimitives.WriteInt32LittleEndian(body.AsSpan(6, 4), sy);
            System.Buffers.Binary.BinaryPrimitives.WriteInt32LittleEndian(body.AsSpan(10, 4), 0);
            body[14] = 0; body[15] = 0; body[16] = 0;
            body[17] = 1; // SpawningIntoWorld
            var buf = new byte[20];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), 20);
            body.CopyTo(buf.AsSpan(2));
            return buf;
        }

        private static byte[] BuildPlayerActive(byte id, bool active)
        {
            var buf = new byte[5];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), 5);
            buf[2] = 14;
            buf[3] = id;
            buf[4] = (byte)(active ? 1 : 0);
            return buf;
        }

        private static byte[] BuildStatusClear()
        {
            var body = new List<byte> { 9 };
            body.AddRange(BitConverter.GetBytes(0));
            body.Add(0);
            body.Add(0);
            body.Add(1);
            var b = body.ToArray();
            var buf = new byte[b.Length + 2];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), (ushort)(b.Length + 2));
            b.CopyTo(buf.AsSpan(2));
            return buf;
        }

        /// <summary>
        /// Only hide other players. Do NOT inject NPC/item/pylon packets —
        /// wrong layouts desync the client stream (no tile edit, no combat).
        /// LoadPlayer + world sections from the new server replace entities.
        /// </summary>
        private async ValueTask ClearEntitiesAsync()
        {
            if (_cleared) return;
            _cleared = true;
            try
            {
                var batch = new List<byte>(255 * 5);
                for (int i = 0; i < 255; i++)
                {
                    if (i == index) continue;
                    batch.AddRange(BuildPlayerActive((byte)i, false));
                }
                if (batch.Count > 0)
                    await SendToClientDirectAsync((ReadOnlyMemory<byte>)batch.ToArray()).ConfigureAwait(false);
                Client.TrackedNpcs.Clear();
                Client.TrackedPylons.Clear();
                Logs.Info($"[{Client.Name}] cleared other players");
            }
            catch { }
        }

        private async ValueTask SendGetSectionAsync()
        {
            if (_sectionSent) return;
            _sectionSent = true;
            await ClearEntitiesAsync().ConfigureAwait(false);
            async ValueTask Req(int x, int y)
            {
                await SendToServerDirectAsync(new RequestTileData
                {
                    Position = new Microsoft.Xna.Framework.Point(x, y),
                    Team = 0,
                }).ConfigureAwait(false);
            }
            await Req(-1, -1).ConfigureAwait(false);
            Logs.Info($"[{Client.Name}] GetSection(-1,-1)");
            short sx = SpawnX > 0 ? SpawnX : (short)4200;
            short sy = SpawnY > 0 ? SpawnY : (short)450;
            foreach (var o in new (int, int)[] { (0, 0), (-200, 0), (200, 0), (0, -150), (0, 150), (-200, -150), (200, 150), (-200, 150), (200, -150) })
                await Req(Math.Max(0, sx + o.Item1), Math.Max(0, sy + o.Item2)).ConfigureAwait(false);
            Logs.Info($"[{Client.Name}] GetSection grid around {sx},{sy}");
        }

        public override ValueTask<bool> RecieveClientDataAsync(HandlerPacketContext context)
            => ValueTask.FromResult(false);

        private async ValueTask FinishedConnectingAsync()
        {
            if (!IsConnecting) return;
            IsConnecting = false;
            try
            {
                await SendToClientDirectAsync((ReadOnlyMemory<byte>)BuildStatusClear()).ConfigureAwait(false);
                if (SpawnX > 0) Client.Player.SpawnX = SpawnX;
                if (SpawnY > 0) Client.Player.SpawnY = SpawnY;
                // Do NOT send a second SpawnPlayer here — it makes TShock print "logged in" twice
            }
            catch { }
            _tcs.TrySetResult(true);
            Parent.DeregisterHandler(this);
            if (Hooks.OnPostSwitch(Client, TargetServer, out _))
                return;
            Client.ArmItemTeleportSuppress(8000);
            Logs.Success($"[{Client.Name}] successfully joined the server: {TargetServer.Name}");
        }

        private async ValueTask TryFinishAsync(string reason)
        {
            if (!IsConnecting || _finishScheduled) return;
            _finishScheduled = true;
            Logs.Info($"[{Client.Name}] completing ({reason}, tiles={_tilePacketsForwarded}) — settling…");
            // Always settle ~1.2s so client applies sections before we mark InGame
            try { await Task.Delay(1200).ConfigureAwait(false); } catch { }
            Logs.Info($"[{Client.Name}] finish after settle tiles={_tilePacketsForwarded}");
            await FinishedConnectingAsync().ConfigureAwait(false);
            _ = Task.Run(async () =>
            {
                try
                {
                    for (int i = 0; i < 3; i++)
                    {
                        await Task.Delay(500).ConfigureAwait(false);
                        await Parent.SendToServerDirectAsync(new RequestTileData { Position = new Microsoft.Xna.Framework.Point(-1, -1), Team = 0 }).ConfigureAwait(false);
                        short sx = SpawnX > 0 ? SpawnX : (short)0;
                        short sy = SpawnY > 0 ? SpawnY : (short)0;
                        if (sx > 0)
                        {
                            await Parent.SendToServerDirectAsync(new RequestTileData { Position = new Microsoft.Xna.Framework.Point(sx, sy), Team = 0 }).ConfigureAwait(false);
                            await Parent.SendToServerDirectAsync(new RequestTileData { Position = new Microsoft.Xna.Framework.Point(sx + 50, sy), Team = 0 }).ConfigureAwait(false);
                            await Parent.SendToServerDirectAsync(new RequestTileData { Position = new Microsoft.Xna.Framework.Point(sx - 50, sy), Team = 0 }).ConfigureAwait(false);
                        }
                    }
                    Logs.Info($"[{Client.Name}] post-join GetSection refresh x3");
                }
                catch (Exception ex) { Logs.Warn($"[{Client.Name}] post section: {ex.Message}"); }
            });
        }

        private async ValueTask HandleSpawnAtWorldAsync(string reason)
        {
            if (_spawnSent) return;
            _spawnSent = true;
            short sx = SpawnX > 0 ? SpawnX : (short)0;
            short sy = SpawnY > 0 ? SpawnY : (short)0;
            Client.Player.SpawnX = sx;
            Client.Player.SpawnY = sy;
            // Correct TrProtocol SpawnPlayer (Point16), not broken int32 raw layout
            await SendToServerDirectAsync(new SpawnPlayer
            {
                PlayerSlot = index,
                Position = new Terraria.DataStructures.Point16(sx, sy),
                Timer = 0,
                DeathsPVE = 0,
                DeathsPVP = 0,
                Team = 0,
                Context = PlayerSpawnContext.SpawningIntoWorld,
            }).ConfigureAwait(false);
            Logs.Info($"[{Client.Name}] {reason} → SpawnPlayer {sx},{sy}");
        }

        public override async ValueTask<bool> RecieveServerDataAsync(HandlerPacketContext context)
        {
            var msgType = context.MessageId;
            byte mid = (byte)msgType;

            switch (msgType)
            {
                case MessageID.Kick:
                    {
                        IsConnecting = false;
                        _tcs.TrySetResult(false);
                        Parent.DeregisterHandler(this);
                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);
                        break;
                    }

                case MessageID.LoadPlayer:
                    {
                        if (context.Packet is not LoadPlayer slot)
                            throw new Exception("[PreConnectHandler] LoadPlayer packet not found");

                        index = slot.PlayerSlot;
                        Client.SetIndex(index);
                        Logs.Info($"[{Client.Name}] remote index: {slot.PlayerSlot}");

                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);
                        await ClearEntitiesAsync().ConfigureAwait(false);

                        // Cross-version (client 326 → backend 319): DO NOT reinject raw client packets.
                        // Raw 1.4.5.8 PlayerInfo/HP/buffs desync TShock 1.4.5.6 (no dig, bad boss HP).
                        // Only send UUID + minimal SyncPlayer built by TrProtocol for 1.4.5.6 layout.
                        try
                        {
                            var name = string.IsNullOrWhiteSpace(Client.Name) ? "Player" : Client.Name;
                            if (name.Length > 20) name = name[..20];
                            await Parent.SendToServerDirectAsync(new SyncPlayer
                            {
                                PlayerSlot = index,
                                SkinVariant = 0,
                                Hair = 0,
                                Name = name,
                                HairDye = 0,
                                Bit1 = default,
                                Bit2 = default,
                                HideMisc = 0,
                                HairColor = Utils.MakeColor(215, 90, 55),
                                SkinColor = Utils.MakeColor(255, 125, 90),
                                EyeColor = Utils.MakeColor(105, 90, 75),
                                ShirtColor = Utils.MakeColor(175, 165, 140),
                                UnderShirtColor = Utils.MakeColor(160, 180, 215),
                                PantsColor = Utils.MakeColor(255, 230, 175),
                                ShoeColor = Utils.MakeColor(160, 105, 60),
                                Bit3 = default,
                                Bit4 = default,
                                Bit5 = default,
                            }).ConfigureAwait(false);

                            // TShock requires a non-blank UUID (blank → kick "Your client sent a blank UUID")
                            // Prefer captured client UUID; else stable GUID from name so same player maps consistently.
                            var uuidStr = Client.Player.UUID;
                            if (string.IsNullOrWhiteSpace(uuidStr))
                            {
                                var seed = "mse:" + (Client.Name ?? Client.IP ?? "player");
                                using (var md5 = System.Security.Cryptography.MD5.Create())
                                {
                                    var hash = md5.ComputeHash(System.Text.Encoding.UTF8.GetBytes(seed));
                                    uuidStr = new Guid(hash).ToString();
                                }
                                Client.Player.UUID = uuidStr;
                            }
                            await Parent.SendToServerDirectAsync(new ClientUUID { UUID = uuidStr }).ConfigureAwait(false);
                            Logs.Info($"[{Client.Name}] reinjected SyncPlayer+UUID ({uuidStr[..Math.Min(8, uuidStr.Length)]}…)");
                        }
                        catch (Exception ex)
                        {
                            Logs.Warn($"[{Client.Name}] reinject: {ex.Message}");
                        }

                        // Optional: only if same-version and config asks for full restore
                        if (!Config.Instance.FakeVersionToBackend && Config.Instance.RestoreDataWhenJoinNonSSC)
                        {
                            var batch = new List<ReadOnlyMemory<byte>>();
                            void Add(byte[]? raw)
                            {
                                if (raw is null || raw.Length < 4) return;
                                batch.Add(Utils.PatchPlayerSlotRaw(raw, index));
                            }
                            Add(Client.Player.RawPlayerHealth);
                            Add(Client.Player.RawPlayerMana);
                            Add(Client.Player.RawPlayerBuffs);
                            foreach (var kv in Client.Player.RawInventory.OrderBy(k => k.Key))
                                Add(kv.Value);
                            if (batch.Count > 0)
                                await Parent.SendToServerBatchAsync(batch).ConfigureAwait(false);
                            Logs.Info($"[{Client.Name}] restored {batch.Count} same-version packets");
                        }

                        await SendToServerDirectAsync(new RequestWorldInfo()).ConfigureAwait(false);
                        break;
                    }

                case MessageID.WorldData:
                    {
                        if (context.Packet is not WorldData worldData)
                            throw new Exception("[PreConnectHandler] WorldData packet not found");

                        World ??= worldData;
                        SpawnX = worldData.SpawnX;
                        SpawnY = worldData.SpawnY;
                        Client.Player.SpawnX = SpawnX;
                        Client.Player.SpawnY = SpawnY;
                        Client.Player.UpdateData(worldData, false);

                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);

                        if (!_sectionSent)
                        {
                            _ = Task.Run(async () =>
                            {
                                try { await SendGetSectionAsync().ConfigureAwait(false); }
                                catch (Exception ex) { Logs.Warn($"[{Client.Name}] section: {ex.Message}"); }
                            });
                        }
                        break;
                    }

                case MessageID.RequestPassword:
                    {
                        await Client.SendErrorMessageAsync(Localization.Instance["Prompt_NeedPassword", TargetServer.Name]).ConfigureAwait(false);
                        IsConnecting = false;
                        _tcs.TrySetResult(false);
                        Parent.DeregisterHandler(this);
                        break;
                    }

                case MessageID.PlayerSpawnSelf:
                    {
                        await HandleSpawnAtWorldAsync("PlayerSpawnSelf").ConfigureAwait(false);
                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);
                        if (!_sectionSent)
                            await SendGetSectionAsync().ConfigureAwait(false);
                        Client.SetIndex(index);
                        break;
                    }

                case MessageID.FinishedConnectingToServer:
                    {
                        if (!_spawnSent)
                            await HandleSpawnAtWorldAsync("finish-fallback").ConfigureAwait(false);
                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);
                        await TryFinishAsync($"FinishedConnecting tiles={_tilePacketsForwarded}").ConfigureAwait(false);
                        break;
                    }

                default:
                    {
                        if (mid == 49 && !_spawnSent)
                        {
                            await HandleSpawnAtWorldAsync("pkt49").ConfigureAwait(false);
                        }
                        await SendToClientDirectAsync(context.Data).ConfigureAwait(false);
                        if (mid is 10 or 11 or 20 or 23 or 21 or 13)
                        {
                            _tilePacketsForwarded++;
                            if (_tilePacketsForwarded <= 3 || _tilePacketsForwarded % 50 == 0)
                                Logs.Info($"[{Client.Name}] tile #{_tilePacketsForwarded}");
                        }
                        break;
                    }
            }
            return true;
        }
    }
}
