using MultiSEngine.Core.Handler;
using MultiSEngine.DataStruct;

namespace MultiSEngine.Core.Adapter
{
    public class BaseAdapter : IAsyncDisposable, IDisposable
    {
        private static bool IsSpamPacket(MessageID id)
        {
            // Quiet console: only log rare connection events
            var b = (byte)id;
            // 1 ConnectRequest, 2 Disconnect, 3 LoadPlayer, 37 password, 68 UUID, 129 Finished
            bool important = b is 1 or 2 or 3 or 37 or 129;
            return !important;
        }

        public BaseAdapter(ClientData client, TcpContainer clientConnection, TcpContainer serverConnection = null)
        {
            Client = client;
            if (clientConnection is not null)
            {
                ClientConnection = clientConnection;
                ClientConnection.OnException += OnConnectionException;
            }
            if (serverConnection is not null)
            {
                SetServerConnection(serverConnection);
            }
            RegisterHandlers();
        }
        #region 变量
        public int ErrorCount { get; protected set; } = 0;
        public bool IsDisposed { get; private set; } = false;
        public ClientData Client { get; private set; }
        protected List<BaseHandler> _handlers { get; set; } = [];

        internal TcpContainer ClientConnection { get; private set; }
        internal TcpContainer ServerConnection { get; private set; }

        private readonly CancellationTokenSource _cts = new();
        private int _started = 0;
        private volatile bool _attached = false;
        private volatile bool _pauseClientToServer = false;
        private volatile bool _pauseServerToClient = false;
        private Func<ReadOnlyMemory<byte>, CancellationToken, ValueTask>? _clientPacketHandler;
        private Func<ReadOnlyMemory<byte>, CancellationToken, ValueTask>? _serverPacketHandler;

        #endregion
        protected virtual void RegisterHandlers()
        {
            if (Client is null)
                return;
            RegisterHandler<CommonHandler>();
            RegisterHandler<CustomPacketHandler>();
            RegisterHandler<PlayerInfoHandler>();
            RegisterHandler<ChatHandler>();
        }
        public async ValueTask SetServerConnectionAsync(TcpContainer serverConnection, bool disposeOld = false)
        {
            // 先取消订阅旧连接的接收回调，避免双读
            try
            {
                if (_attached && ServerConnection is not null && _serverPacketHandler is not null)
                    ServerConnection.UnsubscribePacket(_serverPacketHandler);
            }
            catch (Exception ex)
            {
                Logs.Warn($"[{GetType().Name}] Unsubscribe server packet handler failed: {ex}");
                try { ExceptionRaised?.Invoke(ex); } catch { }
            }
            if (disposeOld && ServerConnection is { })
            {
                try
                {
                    await ServerConnection.DisposeAsync(true).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logs.Warn($"[{GetType().Name}] Dispose old server connection failed: {ex}");
                }
            }
            ServerConnection = serverConnection;
            ServerConnection.OnException += OnConnectionException;
            // 若已启动，立即订阅新连接的数据回调
            if (_attached)
            {
                EnsureServerSubscribed();
                ServerConnection.Start(); // 如果 Adapter 已启动，立即启动新连接的接收
            }
        }

        public void SetServerConnection(TcpContainer serverConnection, bool disposeOld = false)
            => _ = SetServerConnectionAsync(serverConnection, disposeOld);
        public virtual async ValueTask DisposeAsync(bool disposeConnection = true)
        {
            if (IsDisposed)
                return;
            IsDisposed = true;
            _cts.Cancel();
            // 取消订阅，防止回调泄漏
            try
            {
                if (ClientConnection is not null && _clientPacketHandler is not null)
                    ClientConnection.UnsubscribePacket(_clientPacketHandler);
            }
            catch (Exception ex)
            {
                Logs.Warn($"[{GetType().Name}] Unsubscribe client packet handler failed: {ex}");
                try { ExceptionRaised?.Invoke(ex); } catch { }
            }
            try
            {
                if (ServerConnection is not null && _serverPacketHandler is not null)
                    ServerConnection.UnsubscribePacket(_serverPacketHandler);
            }
            catch (Exception ex)
            {
                Logs.Warn($"[{GetType().Name}] Unsubscribe server packet handler failed during dispose: {ex}");
                try { ExceptionRaised?.Invoke(ex); } catch { }
            }
            foreach (var handler in _handlers)
            {
                handler.Dispose();
            }
            _handlers.Clear();
            if (ClientConnection is not null)
                ClientConnection.OnException -= OnConnectionException;
            if (ServerConnection is not null)
                ServerConnection.OnException -= OnConnectionException;
            if (disposeConnection)
            {
                if (ClientConnection is not null)
                    await ClientConnection.DisposeAsync(true).ConfigureAwait(false);
                if (ServerConnection is not null)
                    await ServerConnection.DisposeAsync(true).ConfigureAwait(false);
            }
#if DEBUG
            Logs.Warn($"[{GetType()}] Stopped");
#endif
        }

        public void Dispose()
            => Dispose(true);

        public void Dispose(bool disposeConnection)
            // 改为异步 fire-and-forget，避免阻塞线程
            => _ = DisposeAsync(disposeConnection);

        ValueTask IAsyncDisposable.DisposeAsync()
            => DisposeAsync(true);
        public void Start()
        {
            if (IsDisposed || _cts.IsCancellationRequested)
                return;
            if (Interlocked.CompareExchange(ref _started, 1, 0) != 0)
                return;
            // 1. 订阅回调
            EnsureClientSubscribed();
            EnsureServerSubscribed();

            // 2. 启动 TcpContainer 的接收循环
            ClientConnection?.Start();
            ServerConnection?.Start();

            _attached = true;
        }
        public void PauseRouting(bool pauseClientToServer, bool pauseServerToClient)
        {
            _pauseClientToServer = pauseClientToServer;
            _pauseServerToClient = pauseServerToClient;
        }
        private async ValueTask HandlePacketAsync(bool fromServer, ReadOnlyMemory<byte> memory, CancellationToken cancellationToken)
        {
            try
            {
                if (fromServer)
                {
                    if (_pauseServerToClient)
                        return;
                    // Track NPCs / pylons for Dimensions-style clear on switch
                    try
                    {
                        if (Client is not null && memory.Length >= 5)
                        {
                            byte mid = memory.Span[2];
                            if (mid == 23 && memory.Length >= 5) // NPCUpdate
                            {
                                short npcId = System.Buffers.Binary.BinaryPrimitives.ReadInt16LittleEndian(memory.Span.Slice(3, 2));
                                if (npcId >= 0 && npcId < 200)
                                    Client.TrackedNpcs[npcId] = 1;
                            }
                            else if (mid == 82 && memory.Length >= 8) // LoadNetModule — try parse TeleportPylon
                            {
                                // [len:2][82][moduleId:u16][action:u8][x:i16][y:i16][type:u8]
                                ushort modId = System.Buffers.Binary.BinaryPrimitives.ReadUInt16LittleEndian(memory.Span.Slice(3, 2));
                                // TeleportPylon module id is typically 8 in 1.4.4+
                                if (modId <= 16 && memory.Length >= 12)
                                {
                                    byte action = memory.Span[5];
                                    short px = System.Buffers.Binary.BinaryPrimitives.ReadInt16LittleEndian(memory.Span.Slice(6, 2));
                                    short py = System.Buffers.Binary.BinaryPrimitives.ReadInt16LittleEndian(memory.Span.Slice(8, 2));
                                    byte ptype = memory.Span[10];
                                    if (action == 0) // Added
                                        Client.TrackedPylons[(px, py, ptype)] = 1;
                                    else if (action == 1) // Removed
                                        Client.TrackedPylons.TryRemove((px, py, ptype), out _);
                                }
                            }
                        }
                    }
                    catch { }
                }
                else
                {
                    if (_pauseClientToServer)
                        return;
                }

                var messageId = (MessageID)memory.Span[2];
                // Plugin hook: PlayerUpdate (packet 13) — e.g. MSE.Warps
                if (!fromServer && (byte)messageId == 13 && Client is not null)
                {
                    try { Hooks.OnPlayerUpdate(Client, memory); } catch { }
                }
#if DEBUG
                if (!IsSpamPacket(messageId))
                    Console.WriteLine(fromServer
                        ? $"[Recieve SERVER] {messageId}"
                        : $"[Recieve CLIENT] {messageId}");
#endif
                var context = new HandlerPacketContext(messageId, memory, fromServer);
                // Snapshot handlers — Recieve* may DeregisterHandler mid-loop (e.g. FinishedConnectingAsync)
                var handlersSnapshot = _handlers.ToArray();
                if (fromServer)
                {
                    for (int i = handlersSnapshot.Length - 1; i >= 0; i--)
                    {
                        var h = handlersSnapshot[i];
                        if (h is null) continue;
                        try
                        {
                            if (await h.RecieveServerDataAsync(context).ConfigureAwait(false))
                                return;
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                            // handler list mutated; ignore
                        }
                    }
                    // CL319_326: fix NPC HP / item drops for 326 client on 319 backend
                    memory = Modules.CrossVersionBridge.ServerToClient(memory);
                    // Backend Kick/Disconnect (id 2): forward, then do not let RST race — brief pause
                    if (memory.Length >= 3 && memory.Span[2] == 2)
                    {
                        await SendToClientDirectAsync(memory, cancellationToken).ConfigureAwait(false);
                        try { await Task.Delay(800, cancellationToken).ConfigureAwait(false); } catch { }
                        return;
                    }
                    await SendToClientDirectAsync(memory, cancellationToken).ConfigureAwait(false);
                }
                else
                {
                    // Suppress item-teleport packets during join/switch window (TShock would spam "no permission to teleport using items")
                    // Does NOT grant rod permission — after the window, TShock still blocks cheaters without tshock.tp.rod
                    try
                    {
                        if (Client is not null && memory.Length >= 3)
                        {
                            byte midTp = memory.Span[2];
                            if ((midTp == 65 || midTp == 73) && Environment.TickCount64 < Client.SuppressItemTeleportUntil)
                                return; // drop silently
                        }
                    }
                    catch { }
for (int i = handlersSnapshot.Length - 1; i >= 0; i--)
                    {
                        var h = handlersSnapshot[i];
                        if (h is null) continue;
                        try
                        {
                            if (await h.RecieveClientDataAsync(context).ConfigureAwait(false))
                                return;
                        }
                        catch (ArgumentOutOfRangeException)
                        {
                        }
                    }
                    // Patch player slot ONLY on packets where payload[0] is actually playerId.
                    // Wrong list previously corrupted ModifyTile(17), chests(31/32), StrikeNPC(28), etc.
                    var toSend = memory;
                    if (Client?.Player is { Index: var idx } && memory.Length >= 4)
                    {
                        var mid = (byte)messageId;
                        if (mid is 4 or 5 or 12 or 13 or 14 or 16 or 30 or 35 or 36
                            or 42 or 50 or 51 or 55 or 62 or 65 or 73 or 117 or 118 or 125)
                        {
                            if (memory.Span[3] != idx)
                            {
                                var copy = memory.ToArray();
                                copy[3] = idx;
                                toSend = copy;
                            }
                        }
                    }
                    toSend = Modules.CrossVersionBridge.ClientToServer(toSend);
                    await SendToServerDirectAsync(toSend, cancellationToken).ConfigureAwait(false);
                }
            }
            catch (OperationCanceledException)
            {
            }
            catch (ObjectDisposedException)
            {
                // connection already closed
            }
            catch (Exception ex)
            {
                ErrorCount++;
                Logs.Error($"An error occurred while processing {(fromServer ? "SERVER" : "CLIENT")} packets.{Environment.NewLine}{ex}");
                try { ExceptionRaised?.Invoke(ex); } catch { }
            }
        }
        private void EnsureClientSubscribed()
        {
            if (ClientConnection is null || ClientConnection.IsDisposed)
                return;
            _clientPacketHandler ??= async (mem, token) => await HandlePacketAsync(fromServer: false, mem, token);
            ClientConnection.SubscribePacket(_clientPacketHandler);
        }
        private void EnsureServerSubscribed()
        {
            if (ServerConnection is null || ServerConnection.IsDisposed)
                return;
            _serverPacketHandler ??= async (mem, token) => await HandlePacketAsync(fromServer: true, mem, token);
            ServerConnection.SubscribePacket(_serverPacketHandler);
        }

        public event Action<Exception> ExceptionRaised;

        public virtual void OnConnectionException(Exception ex)
        {
            ErrorCount++;
            Logs.Error($"Connection error: {ex}");
            try { ExceptionRaised?.Invoke(ex); } catch { }
        }


        public void RegisterHandler(BaseHandler handler)
        {
            handler.Initialize();
            _handlers.Add(handler);
        }
        public void RegisterHandler<T>() where T : BaseHandler
        {
            var handler = Activator.CreateInstance(typeof(T), new object[] { this }) as BaseHandler;
            RegisterHandler(handler);
        }
        public bool DeregisterHandler<T>(T handler) where T : BaseHandler
        {
            handler?.Dispose();
            return _handlers.Remove(handler);
        }

        #region Packet Send

        public async ValueTask<bool> SendToClientDirectAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            if (IsDisposed || ClientConnection is null || ClientConnection.IsDisposed)
            {
                return false;
            }
#if DEBUG
            if ((MessageID)buffer.Span[2] is MessageID.NetModules)
            {
                // muted NetModules spam
            }
            else
            {
                { var mid=(MessageID)buffer.Span[2]; if (!IsSpamPacket(mid)) Console.WriteLine($"[Internal Send TO CLIENT] {mid}"); }
            }
#endif

            var sendContext = ClientConnection.GetSendPipeline();
            return await sendContext.SendViaPipelineAsync(buffer, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToClientBatchAsync(IReadOnlyList<ReadOnlyMemory<byte>> buffers, CancellationToken cancellationToken = default)
        {
            if (ClientConnection is null)
            {
#if DEBUG
                Console.WriteLine($"[Internal Batch TO CLIENT] Connection is null");
#endif
                return false;
            }
#if DEBUG
            if (buffers.Count > 0)
            {
                var first = buffers[0];
                if (first.Length >= 3)
                    Console.WriteLine($"[Internal Batch TO CLIENT] <{buffers.Count}> {string.Join(", ", buffers.Select(b => (MessageID)b.Span[2]))}");
                else
                    Console.WriteLine($"[Internal Batch TO CLIENT] <header-less> x{buffers.Count}");
            }
#endif

            var sendContext = ClientConnection.GetSendPipeline();
            return await sendContext.SendViaPipelineBatchAsync(buffers, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToServerDirectAsync(ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            if (IsDisposed || ServerConnection is null || ServerConnection.IsDisposed)
            {
#if DEBUG
                if (Client.CurrentServer is not null)
                    Console.WriteLine($"[Internal Send TO SERVER] Connection is null");
#endif
                return false;
            }
#if DEBUG
            { var mid=(MessageID)buffer.Span[2]; if (!IsSpamPacket(mid)) Console.WriteLine($"[Internal Send TO SERVER] {mid}"); }
#endif

            var sendContext = ServerConnection.GetSendPipeline();
            return await sendContext.SendViaPipelineAsync(buffer, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToServerBatchAsync(IReadOnlyList<ReadOnlyMemory<byte>> buffers, CancellationToken cancellationToken = default)
        {
            if (ServerConnection is null)
            {
#if DEBUG
                Console.WriteLine($"[Internal Batch TO SERVER] Connection is null");
#endif
                return false;
            }
#if DEBUG
            if (buffers.Count > 0)
            {
                var first = buffers[0];
                if (first.Length >= 3)
                    Console.WriteLine($"[Internal Batch TO SERVER] {(MessageID)first.Span[2]} x{buffers.Count}");
                else
                    Console.WriteLine($"[Internal Batch TO SERVER] <header-less> x{buffers.Count}");
            }
#endif

            var sendContext = ServerConnection.GetSendPipeline();
            return await sendContext.SendViaPipelineBatchAsync(buffers, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToClientDirectAsync(INetPacket packet, CancellationToken cancellationToken = default)
        {
            using var rental = packet.AsPacketRental(toClient: true);
            return await SendToClientDirectAsync(rental.Memory, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToClientBatchAsync(INetPacket[] packets, CancellationToken cancellationToken = default)
        {
            using var rentals = new PacketBatchRental(packets);
            return await SendToClientBatchAsync(rentals.Buffers, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToServerDirectAsync(INetPacket packet, CancellationToken cancellationToken = default)
        {
            using var rental = packet.AsPacketRental(toClient: false);
            return await SendToServerDirectAsync(rental.Memory, cancellationToken).ConfigureAwait(false);
        }
        public async ValueTask<bool> SendToServerBatchAsync(INetPacket[] packets, CancellationToken cancellationToken = default)
        {
            using var rentals = new PacketBatchRental(packets);
            return await SendToServerBatchAsync(rentals.Buffers, cancellationToken).ConfigureAwait(false);
        }

        protected virtual void ConfigureSendPipeline(TcpContainer.SendPipelineContext context)
        {
            // 保留虚方法以便子类扩展，例如追加额外的发送参数
        }

        private readonly struct PacketBatchRental : IDisposable
        {
            private readonly Utils.PacketMemoryRental[] _rentals;
            public PacketBatchRental(INetPacket[] packets)
            {
                var count = packets.Length;
                _rentals = new Utils.PacketMemoryRental[count];
                Buffers = new ReadOnlyMemory<byte>[count];
                for (int i = 0; i < count; i++)
                {
                    _rentals[i] = packets[i].AsPacketRental();
                    Buffers[i] = _rentals[i].Memory;
                }
            }

            public ReadOnlyMemory<byte>[] Buffers { get; }

            public void Dispose()
            {
                for (int i = 0; i < _rentals.Length; i++)
                {
                    _rentals[i].Dispose();
                }
            }
        }
        #endregion
    }
}
