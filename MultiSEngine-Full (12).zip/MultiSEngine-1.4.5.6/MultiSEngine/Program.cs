using System.Reflection;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MultiSEngine
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            ShowLogo();
            Console.CancelKeyPress += (_, e) =>
            {
                e.Cancel = true;
                _ = ShutdownFromSignal();
            };
            AutoInit();
            while (true)
            {
                var line = await Console.In.ReadLineAsync();
                if (line is null) break;
                var (handled, continueSend) = await Core.Command.HandleCommand(null, line, true).ConfigureAwait(false);
                if (handled && !continueSend)
                    break;
            }
            await CloseAsync().ConfigureAwait(false);
            Console.WriteLine("Bye!");
        }

        static async Task ShutdownFromSignal()
        {
            try { await CloseAsync().ConfigureAwait(false); } catch { }
            Environment.Exit(0);
        }

        private static void ShowLogo()
        {
            Console.WriteLine(@"
        __  ___      ____  _ _____ ______            _          
       /  |/  /_  __/ / /_(_) ___// ____/___  ____ _(_)___  ___ 
      / /|_/ / / / / / __/ /\__ \/ __/ / __ \/ __ `/ / __ \/ _ \
     / /  / / /_/ / / /_/ /___/ / /___/ / / / /_/ / / / / /  __/
    /_/  /_/\__,_/_/\__/_//____/_____/_/ /_/\__, /_/_/ /_/\___/ 
                                       /____/               
");
            Console.WriteLine($"-> V{Assembly.GetExecutingAssembly().GetName().Version}");
            Console.WriteLine();
        }
        private static void AutoInit()
        {
#if DEBUG
            Logs.Warn($"> MultiSEngine IS IN DEBUG MODE <");
#endif
            Logs.Init();
            Logs.Info("Initializing the program...");
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);
            var auto = new Dictionary<MethodInfo, AutoInitAttribute>();
            Assembly.GetExecutingAssembly()
                        .GetTypes()
                        .ForEach(t => t.GetMethods(BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public)
                        .ForEach(m =>
                        {
                            if (m.GetCustomAttribute<AutoInitAttribute>() is { } attr)
                                auto.Add(m, attr);
                        }));
            auto.OrderBy(a => a.Value.Order).ForEach(kv =>
            {
                try
                {
#if DEBUG
                    Console.WriteLine($"[{kv.Key.DeclaringType.Name}.{kv.Key.Name}] => Initialzing");
#endif
                    var attr = kv.Value;
                    if (attr.PreInitMessage is { } pre)
                        Logs.Info(pre);
                    kv.Key.Invoke(null, null);
                    if (attr.PostInitMessage is { } post)
                        Logs.Info(post);
                }
                catch (Exception ex)
                {
                    Logs.Error($"An error occurred while initilizing: [{kv.Key.DeclaringType.Name}.{kv.Key.Name}]{Environment.NewLine}{ex}");
                }
            });
            Logs.Success($"MultiSEngine startted.");
        }
        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logs.Error(e.ExceptionObject as Exception is { } error ? string.Format("Application UnhandledException:{0};\nStackTrace:{1}", error.Message, error.StackTrace) : string.Format("Application UnhandledError:{0}", e));
        }
        public static async Task CloseAsync()
        {
            Logs.Info("Shutting down...");
            const string msg = "Server offline. MultiSEngine is shutting down.";
            var clients = Data.Clients.ToArray();
            foreach (var c in clients)
            {
                try { await c.DisconnectAsync(msg).ConfigureAwait(false); } catch { }
            }
            // Let kick/chat packets flush to clients
            if (clients.Length > 0)
                await Task.Delay(2000).ConfigureAwait(false);
            try { Core.PluginSystem.Unload(); } catch { }
            Logs.Info("Server closed. Goodbye.");
        }
    }
}
