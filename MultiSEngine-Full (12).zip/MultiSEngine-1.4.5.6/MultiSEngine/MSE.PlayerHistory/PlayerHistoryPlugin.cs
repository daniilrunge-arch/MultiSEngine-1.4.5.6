using MultiSEngine;
using MultiSEngine.Core;

namespace MSE.PlayerHistory;

/// <summary>
/// Optional marker. /player and /play are built into MultiSEngine core.
/// </summary>
public class PlayerHistoryPlugin : IMSEPlugin
{
    public string Name => "PlayerHistory";
    public string Description => "/player is built into the proxy";
    public string Author => "MultiSEngine";
    public Version Version => new(1, 0, 0);
    public void Initialize() => Logs.Info("[PlayerHistory] loaded (/player is built-in)");
    public void Dispose() { }
}
