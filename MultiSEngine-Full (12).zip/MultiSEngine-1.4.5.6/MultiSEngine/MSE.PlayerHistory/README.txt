Build from this folder AFTER MultiSEngine builds:
  cd ..
  dotnet build -c Release
  cd MSE.PlayerHistory
  dotnet build -c Release
  copy bin\Release\net9.0\MSE.PlayerHistory.dll ..\Plugins\

NOTE: /player is already built into the proxy. This plugin is optional.
