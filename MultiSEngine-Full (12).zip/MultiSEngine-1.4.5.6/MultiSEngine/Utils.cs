using Terraria.Localization;
using Microsoft.Xna.Framework;
using System.Buffers;
using System.Net;
using System.Net.Sockets;
using MultiSEngine.DataStruct;

namespace MultiSEngine
{
    public static class Utils
    {

        public static Color MakeColor(byte r, byte g, byte b, byte a = 255)
            => new Color { R = r, G = g, B = b, A = a };
        public static NetworkText MakeLiteral(string text)
            => new NetworkText(text ?? string.Empty, NetworkText.Mode.Literal);
        private const int DefaultPacketBufferSize = 1024 * 16;

        /// <summary>
        /// 封装 NetPacket 序列化后的缓冲租借，确保使用完及时归还内存池。
        /// </summary>
        public sealed class PacketMemoryRental : IDisposable
        {
            private IMemoryOwner<byte>? _owner;

            public PacketMemoryRental(IMemoryOwner<byte> owner, int length)
            {
                _owner = owner;
                Memory = owner.Memory.Slice(0, length);
            }

            public ReadOnlyMemory<byte> Memory { get; }

            public void Dispose()
            {
                _owner?.Dispose();
                _owner = null;
            }
        }
        private static PacketSerializer? _s2cSerializer; // server -> client
        private static PacketSerializer? _c2sSerializer; // client -> server

        private static PacketSerializer GetS2CSerializer()
        {
            return _s2cSerializer ??= new PacketSerializer(true);
        }
        private static PacketSerializer GetC2SSerializer()
        {
            return _c2sSerializer ??= new PacketSerializer(false);
        }

        private sealed class ReadOnlyMemoryStream : Stream
        {
            private readonly ReadOnlyMemory<byte> _buffer;
            private int _position;
            public ReadOnlyMemoryStream(ReadOnlyMemory<byte> buffer) => _buffer = buffer;
            public override bool CanRead => true;
            public override bool CanSeek => true;
            public override bool CanWrite => false;
            public override long Length => _buffer.Length;
            public override long Position { get => _position; set => _position = (int)value; }
            public override void Flush() { }
            public override int Read(byte[] buffer, int offset, int count)
            {
                var remaining = _buffer.Length - _position;
                if (remaining <= 0) return 0;
                var n = Math.Min(remaining, count);
                _buffer.Span.Slice(_position, n).CopyTo(buffer.AsSpan(offset, n));
                _position += n;
                return n;
            }
            public override long Seek(long offset, SeekOrigin origin)
            {
                long target = origin switch
                {
                    SeekOrigin.Begin => offset,
                    SeekOrigin.Current => _position + offset,
                    SeekOrigin.End => Length + offset,
                    _ => throw new ArgumentOutOfRangeException(nameof(origin))
                };
                if (target < 0 || target > Length) throw new IOException("Attempted to seek outside the buffer");
                _position = (int)target; return _position;
            }
            public override void SetLength(long value) => throw new NotSupportedException();
            public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
        }

        public static INetPacket? AsPacket(this ReadOnlySpan<byte> buf, bool fromServer = true)
            => AsPacket((ReadOnlyMemory<byte>)buf.ToArray(), fromServer);

        public static INetPacket? AsPacket(this ReadOnlyMemory<byte> buf, bool fromServer = true)
        {
            using var ms = new ReadOnlyMemoryStream(buf);
            using var br = new BinaryReader(ms);
            return (fromServer ? GetS2CSerializer() : GetC2SSerializer()).Deserialize(br);
        }
        // Generic AsPacket<T> removed: INetPacket has static abstract members (CS8920).
        // Use AsPacket(...) and pattern-match: if (AsPacket(buf) is MyPacket p)


        /// <summary>
        /// Extract player name from raw SyncPlayer / PlayerInfo packet bytes.
        /// Needed because old TrProtocol misses 1.4.5 voice fields and leaves Name empty.
        /// </summary>

        /// <summary>
        /// Patch PlayerSlot (byte at payload offset 0) in a raw Terraria frame.
        /// Frame layout: [len:u16 LE][msgId:u8][playerSlot:u8][...]
        /// </summary>
        public static byte[] PatchPlayerSlotRaw(ReadOnlySpan<byte> frame, byte newSlot)
        {
            var buf = frame.ToArray();
            if (buf.Length >= 4)
                buf[3] = newSlot;
            return buf;
        }

        public static string? TryExtractPlayerName(ReadOnlySpan<byte> frame)
        {
            // frame = [len:u16][msgId:u8][payload...]
            if (frame.Length < 8) return null;
            var payload = frame[3..];
            // Scan for length-prefixed UTF8 string of reasonable player-name length
            for (int i = 0; i < Math.Min(payload.Length - 2, 40); i++)
            {
                int len = payload[i];
                // 7-bit encoded length usually 1 byte for names <= 127
                if (len < 1 || len > 24) continue;
                if (i + 1 + len > payload.Length) continue;
                var slice = payload.Slice(i + 1, len);
                bool ok = true;
                foreach (var b in slice)
                {
                    if (b < 0x20 || b > 0x7E) { ok = false; break; }
                }
                if (!ok) continue;
                var name = System.Text.Encoding.UTF8.GetString(slice);
                if (name.Length >= 1 && name.Length <= 24)
                    return name;
            }
            return null;
        }

        public static PacketMemoryRental AsPacketRental(this INetPacket packet, int bufferSizeHint = DefaultPacketBufferSize, bool toClient = true)
        {
            // ISideSpecific packets need IsServerSide set: true when writing S2C (to client)
            if (packet is TrProtocol.Interfaces.ISideSpecific side)
                side.IsServerSide = toClient;

            // Use matching serializer orientation
            var ser = toClient ? GetS2CSerializer() : GetC2SSerializer();
            var bytes = ser.Serialize(packet);
            var owner = MemoryPool<byte>.Shared.Rent(Math.Max(bytes.Length, bufferSizeHint));
            var memory = owner.Memory;
            bytes.CopyTo(memory);
            return new PacketMemoryRental(owner, bytes.Length);
        }
        public static ReadOnlyMemory<byte> AsReadOnlyMemory(this INetPacket packet, out PacketMemoryRental rental, int bufferSizeHint = DefaultPacketBufferSize)
        {
            rental = packet.AsPacketRental(bufferSizeHint);
            return rental.Memory;
        }
        public static ClientData[] Online(this ServerInfo server) => Modules.Data.Clients.Where(c => c.CurrentServer == server).ToArray();
        public static bool TryParseAddress(string address, out IPAddress ip)
        {
            ip = default;
            try
            {
                if (IPAddress.TryParse(address, out ip))
                {
                    return true;
                }
                else
                {
                    IPHostEntry hostinfo = Dns.GetHostEntry(address);
                    if (hostinfo.AddressList.FirstOrDefault() is { } _ip)
                    {
                        ip = _ip;
                        return true;
                    }
                }
            }
            catch { }
            return false;
        }

        /// <summary>
        /// 异步解析地址, 优先返回字面 IP, 否则进行 DNS 查询。
        /// </summary>
        public static async ValueTask<IPAddress?> ResolveAddressAsync(string address, CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrWhiteSpace(address))
                return null;

            if (IPAddress.TryParse(address, out var ip))
            {
                return ip;
            }

            try
            {
                var hostInfo = await Dns.GetHostEntryAsync(address).WaitAsync(cancellationToken).ConfigureAwait(false);
                return hostInfo.AddressList.FirstOrDefault();
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch
            {
                return null;
            }
        }
        public static ServerInfo[] GetServersInfoByName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return [];
            var n = name.Trim().ToLowerInvariant();
            // Exact name or short name first
            var exact = Config.Instance.Servers.Where(s =>
                s.Name.Equals(name, StringComparison.OrdinalIgnoreCase) ||
                (!string.IsNullOrEmpty(s.ShortName) && s.ShortName.Equals(name, StringComparison.OrdinalIgnoreCase))).ToArray();
            if (exact.Length > 0) return exact;
            return Config.Instance.Servers.Where(s =>
                s.Name.ToLowerInvariant().StartsWith(n) ||
                s.Name.ToLowerInvariant().Contains(n) ||
                (!string.IsNullOrEmpty(s.ShortName) && s.ShortName.ToLowerInvariant().Contains(n))).ToArray();
        }
        public static bool IsOnline(this TcpClient c)
        {
            return !((c.Client.Poll(1000, SelectMode.SelectRead) && (c.Client.Available == 0)) || !c.Client.Connected);
        }
        public static ServerInfo GetSingleServerInfoByName(string name)
        {
            if (GetServersInfoByName(name) is { } temp && temp.Any())
                return temp.First();
            return null;
        }
        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            if (source == null)
            {
                throw new ArgumentNullException(nameof(source));
            }
            if (action == null)
            {
                throw new ArgumentNullException(nameof(action));
            }
            foreach (T obj in source)
            {
                action(obj);
            }
        }
                public static PacketMemoryRental GetTileSection(int x, int y, short width, short height, int type = 541)
        {
            var flags1 = default(ComplexTileFlags1);
            flags1.TileActive = true;
            flags1.TileTypeIs2Bytes = true;
            var tile = new ComplexTileData
            {
                Flags1 = flags1,
                TileType = (ushort)type,
            };
            var list = new ComplexTileData[width * height];
            for (int i = 0; i < list.Length; i++)
                list[i] = tile;
            return new TileSection
            {
                Data = new SectionData
                {
                    StartX = x,
                    StartY = y,
                    Width = width,
                    Height = height,
                    Tiles = list,
                    ChestCount = 0,
                    Chests = null!,
                    SignCount = 0,
                    Signs = null!,
                    TileEntityCount = 0,
                    TileEntities = null!,
                }
            }.AsPacketRental();
        }
        public static string GetText(this NetworkText text)
        {
            return text?.ToString() ?? string.Empty;
        }
    }
}
