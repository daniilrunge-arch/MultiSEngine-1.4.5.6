namespace MultiSEngine.DataStruct
{
    public class PlayerInfo(bool isOriginCharacter = false)
    {
        public bool IsOriginCharacter => isOriginCharacter;
        public bool SSC => ServerCharacter is { } sc && sc.WorldData.EventInfo1[6];
        public int VersionNum { get; set; } = -1;
        public byte Index { get; set; } = 0;
        public string Name => !string.IsNullOrEmpty(ServerCharacter?.Info.Name) ? ServerCharacter!.Info.Name : (OriginCharacter?.Info.Name ?? "");
        public string UUID { get; set; } = "";
        public int SpawnX { get; set; } = -1;
        public int SpawnY { get; set; } = -1;
        public short WorldSpawnX => ServerCharacter is { } sc ? sc.WorldData.SpawnX : OriginCharacter.WorldData.SpawnX;
        public short WorldSpawnY => ServerCharacter is { } sc ? sc.WorldData.SpawnY : OriginCharacter.WorldData.SpawnY;
        public float X { get; set; } = -1;
        public float Y { get; set; } = -1;
        public int TileX => (int)(X / 16);
        public int TileY => (int)(Y / 16);

        #region 首次登录时提供的信息
        public int Timer = 0;
        public short DeathsPVE = 0;
        public short DeathsPVP = 0;
        public PlayerSpawnContext Context = PlayerSpawnContext.SpawningIntoWorld;
        #endregion


        // Raw packets from client (for reinject without broken TrProtocol reserialize)
        public byte[]? RawSyncPlayer { get; set; }
        public byte[]? RawClientUUID { get; set; }
        public byte[]? RawPlayerHealth { get; set; }
        public byte[]? RawPlayerMana { get; set; }
        public byte[]? RawPlayerBuffs { get; set; }
        public Dictionary<short, byte[]> RawInventory { get; set; } = new();

        public void UpdateData(INetPacket packet, bool fromClient)
        {
            if (packet is null)
                return;
            var data = SSC ? ServerCharacter : OriginCharacter;
            switch (packet)
            {
                case SyncEquipment item:
                    // Terraria 1.4.5+ can send higher slot indices; protect against OOB
                    if (item.ItemSlot < 0 || item.ItemSlot >= data.Inventory.Length)
                        return;
                    if (!SSC)
                        OriginCharacter.Inventory[item.ItemSlot] = item;
                    else
                        ServerCharacter.Inventory[item.ItemSlot] = item;
                    break;
                case PlayerHealth health:
                    data.Health = health.StatLife;
                    data.HealthMax = health.StatLifeMax;
                    break;
                case PlayerMana mana:
                    data.Mana = mana.StatMana;
                    data.ManaMax = mana.StatManaMax;
                    break;
                case SyncPlayer playerInfo:
                    data.Info = playerInfo;
                    break;
                case WorldData world:
                    world.WorldName = string.IsNullOrEmpty(Config.Instance.ServerName) ? world.WorldName : Config.Instance.ServerName;
                    ServerCharacter.WorldData = world;
                    break;
                case PlayerControls control:
                    X = control.Position.X;
                    Y = control.Position.Y;
                    break;
            }
        }

        #region 用于临时储存玩家的原始信息
        public CharacterData OriginCharacter { get; set; } = new();
        public CharacterData ServerCharacter { get; set; } = new();
        #endregion
    }
}
