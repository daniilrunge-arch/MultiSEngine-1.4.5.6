using System.Buffers.Binary;

namespace MultiSEngine.Modules
{
    /// <summary>
    /// Port of Dimensions plugin CL319_326: fix 1.4.5.6 (319) ↔ 1.4.5.8 (326) packet skew.
    /// - NPCUpdate (23): clamp negative HP tail (boss shows -500 / -999)
    /// - ItemOwner (22): expand 14-byte 319 packet to 17-byte 326 layout (loot pickup)
    /// Tile/combat packets stay raw passthrough.
    /// </summary>
    public static class CrossVersionBridge
    {
        /// <summary>Server → client transforms when client is newer protocol.</summary>
        public static ReadOnlyMemory<byte> ServerToClient(ReadOnlyMemory<byte> memory)
        {
            if (!Config.Instance.FakeVersionToBackend || memory.Length < 3)
                return memory;
            var mid = memory.Span[2];
            if (mid == 23)
                return NpcUpdateDeathFix(memory);
            if (mid == 22)
                return ItemOwnerTo326(memory);
            return memory;
        }

        /// <summary>Client → server (usually passthrough; reserved for future 326→319 shrink).</summary>
        public static ReadOnlyMemory<byte> ClientToServer(ReadOnlyMemory<byte> memory)
            => memory;

        static ReadOnlyMemory<byte> NpcUpdateDeathFix(ReadOnlyMemory<byte> memory)
        {
            try
            {
                if (memory.Length < 16) return memory;
                var buf = memory.ToArray();
                bool changed = false;

                // Replace -999 markers
                for (int off = 3; off + 2 <= buf.Length; off++)
                {
                    if (BinaryPrimitives.ReadInt16LittleEndian(buf.AsSpan(off, 2)) == -999)
                    {
                        BinaryPrimitives.WriteInt16LittleEndian(buf.AsSpan(off, 2), 0);
                        changed = true;
                    }
                }

                // Clamp negative values in life tail
                int tailStart = Math.Max(3, buf.Length - 20);
                for (int off = tailStart; off + 2 <= buf.Length; off++)
                {
                    short v = BinaryPrimitives.ReadInt16LittleEndian(buf.AsSpan(off, 2));
                    if (v < 0)
                    {
                        BinaryPrimitives.WriteInt16LittleEndian(buf.AsSpan(off, 2), 0);
                        changed = true;
                    }
                }
                for (int off = tailStart; off + 4 <= buf.Length; off++)
                {
                    int v = BinaryPrimitives.ReadInt32LittleEndian(buf.AsSpan(off, 4));
                    if (v < 0 && v > -500_000)
                    {
                        BinaryPrimitives.WriteInt32LittleEndian(buf.AsSpan(off, 4), 0);
                        changed = true;
                    }
                }

                if (changed)
                {
                    BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), (ushort)buf.Length);
                    return buf;
                }
            }
            catch { }
            return memory;
        }

        /// <summary>319 ItemOwner is 14 bytes; 326 expects 17 (extra flags + pad).</summary>
        static ReadOnlyMemory<byte> ItemOwnerTo326(ReadOnlyMemory<byte> memory)
        {
            try
            {
                var span = memory.Span;
                if (span.Length == 17) return memory;
                if (span.Length == 14)
                {
                    // [len:2][22][itemId:i16][owner:u8][x:f32][y:f32]  total 14
                    short id = BinaryPrimitives.ReadInt16LittleEndian(span.Slice(3, 2));
                    byte owner = span[5];
                    float x = BitConverter.ToSingle(span.Slice(6, 4));
                    float y = BitConverter.ToSingle(span.Slice(10, 4));
                    var outb = new byte[17];
                    BinaryPrimitives.WriteUInt16LittleEndian(outb.AsSpan(0, 2), 17);
                    outb[2] = 22;
                    BinaryPrimitives.WriteInt16LittleEndian(outb.AsSpan(3, 2), id);
                    outb[5] = owner;
                    outb[6] = 0;
                    BinaryPrimitives.WriteUInt16LittleEndian(outb.AsSpan(7, 2), 0);
                    BitConverter.TryWriteBytes(outb.AsSpan(9, 4), x);
                    BitConverter.TryWriteBytes(outb.AsSpan(13, 4), y);
                    return outb;
                }
            }
            catch { }
            return memory;
        }
    }
}
