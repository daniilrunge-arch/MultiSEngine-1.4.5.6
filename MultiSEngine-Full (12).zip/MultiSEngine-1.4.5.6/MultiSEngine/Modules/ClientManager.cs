using TrProtocol.NetPackets.Modules;
using Terraria.Localization;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MultiSEngine.Core;
using MultiSEngine.DataStruct;

namespace MultiSEngine.Modules
{
    /// <summary>
    /// 服务器切换
    /// </summary>
    public static partial class ClientManager
    {
        /// <summary>
        /// 加入到指定的服务器
        /// </summary>
        /// <param name="client"></param>
        /// <param name="server"></param>

        /// <summary>Apply switch freeze debuffs immediately (client-side visual).</summary>
        static ValueTask ApplySwitchDebuffsAsync(ClientData client)
        {
            // Disabled: switch debuffs break mining after /mse tp
            _ = client;
            return ValueTask.CompletedTask;
        }

        public static async Task Join(this ClientData client, ServerInfo server, CancellationToken cancel = default)
        {
            if (Hooks.OnPreSwitch(client, server, out _))
                return;

            if (client.CurrentServer?.Name == server?.Name || (client.State > ClientState.ReadyToSwitch && client.State < ClientState.InGame))
            {
                if (client.CurrentServer == server)
                    await client.SendErrorMessageAsync(string.Format(Localization.Get("Command_AlreadyIn"), server.Name)).ConfigureAwait(false);
                Logs.Warn($"Unallowed transmission requests for [{client.Name}]");
                return;
            }

            Logs.Info($"Switching [{client.Name}] to the server: [{server?.Name ?? "DefaultWorld"}]");
            client.State = ClientState.ReadyToSwitch;

            try
            {
                try
                {
                    client.State = ClientState.Switching;
                    await ApplySwitchDebuffsAsync(client).ConfigureAwait(false); // immediate on /mse tp
                    client.Adapter?.PauseRouting(true, true);

                    // 创建临时适配器，订阅客户端连接；并暂时关闭主适配器的上行转发，避免与临时适配器并发上行
                    client.TempAdapter = new(client, client.Adapter.ClientConnection, server);

                    cancel = cancel == default ? new CancellationTokenSource(Config.Instance.SwitchTimeOut).Token : cancel;
                    await client.TempAdapter.TryConnect(cancel).ConfigureAwait(false);

                    // 先停止临时适配器的订阅，再迁移连接，避免同一 ServerConnection 双读
                    await client.TempAdapter.DisposeAsync(false).ConfigureAwait(false);

                    // 切换完成，接管新服务器连接并清理临时适配器
                    client.LastServer = client.CurrentServer;
                    client.CurrentServer = server;
                    client.State = ClientState.InGame;
                    await client.Adapter.SetServerConnectionAsync(client.TempAdapter.ServerConnection, true).ConfigureAwait(false);
                    client.Player.ServerCharacter.WorldData = client.TempAdapter.ConnectHandler.World ?? default;
                    client.Player.SpawnX = client.TempAdapter.ConnectHandler.SpawnX;
                    client.Player.SpawnY = client.TempAdapter.ConnectHandler.SpawnY;
                    client.Adapter?.PauseRouting(false, false);

                    client.TempAdapter = null;
                    client.Adapter?.PauseRouting(false, false);
                    client.State = ClientState.InGame;
                    await client.SyncAsync(server, cancel).ConfigureAwait(false);

                    // Ensure routing fully open after switch
                    client.Adapter?.PauseRouting(false, false);

                    // Force tile reload so mining works after dimension switch
                    try
                    {
                        byte idx = client.Player.Index;
                        // Ensure this player is active on client view
                        var active = new byte[5];
                        System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(active.AsSpan(0, 2), 5);
                        active[2] = 14; // PlayerActive
                        active[3] = idx;
                        active[4] = 1;
                        await client.Adapter.SendToClientDirectAsync((ReadOnlyMemory<byte>)active).ConfigureAwait(false);

                        var sx = client.Player.SpawnX > 0 ? client.Player.SpawnX : 0;
                        var sy = client.Player.SpawnY > 0 ? client.Player.SpawnY : 0;
                        async ValueTask Req(int x, int y)
                        {
                            await client.Adapter.SendToServerDirectAsync(new RequestTileData
                            {
                                Position = new Microsoft.Xna.Framework.Point(x, y),
                                Team = 0,
                            }).ConfigureAwait(false);
                        }
                        await Req(-1, -1).ConfigureAwait(false);
                        if (sx > 0)
                        {
                            await Req(sx, sy).ConfigureAwait(false);
                            foreach (var o in new (int,int)[] { (-200,0),(200,0),(0,-150),(0,150),(-200,-150),(200,150) })
                                await Req(sx + o.Item1, sy + o.Item2).ConfigureAwait(false);
                        }
                        Logs.Info($"[{client.Name}] post-switch RequestTileData grid");
                        // Keep pulling sections for a few seconds (async)
                        _ = Task.Run(async () =>
                        {
                            try
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    await Task.Delay(600).ConfigureAwait(false);
                                    await Req(-1, -1).ConfigureAwait(false);
                                    if (sx > 0) await Req(sx, sy).ConfigureAwait(false);
                                }
                                Logs.Info($"[{client.Name}] tile pull loop done");
                            }
                            catch { }
                        });
                    }
                    catch (Exception ex) { Logs.Warn($"tile req: {ex.Message}"); }

                    // Debuffs again after switch (player is on new world)
                    await ApplySwitchDebuffsAsync(client).ConfigureAwait(false);
                    client.ArmItemTeleportSuppress(8000);
                    Logs.Success($"[{client.Name}] now on {server.Name} (slot={client.Player.Index})");
                }
                catch (InvalidOperationException ex)
                {
                    await HandleSwitchFailureAsync(client, ex, Localization.Instance["Prompt_UnknownAddress"]).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    await HandleSwitchFailureAsync(client, ex, Localization.Instance["Prompt_CannotConnect", server.Name]).ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Logs.Error($"An error occurred while switching servers: {ex}");
            }
        }

        private static async ValueTask HandleSwitchFailureAsync(ClientData client, Exception ex, string message)
        {
            client.State = ClientState.ReadyToSwitch;
            client.Adapter?.PauseRouting(false, false);
            if (client.TempAdapter?.ServerConnection is { })
                await client.TempAdapter.ServerConnection.DisposeAsync(true).ConfigureAwait(false);
            if (client.TempAdapter is { })
                await client.TempAdapter.DisposeAsync().ConfigureAwait(false);
            client.TempAdapter = null;
            Logs.Error($"Unable to connect to server: {client?.Name ?? "<unknown>"}{Environment.NewLine}{ex}");
            await client.SendErrorMessageAsync(message).ConfigureAwait(false);
        }
        public static async ValueTask BackAsync(this ClientData client, CancellationToken cancellationToken = default)
        {
            if (client is null)
                return;

            var def = Config.Instance.DefaultServerInternal;
            if (def is null)
            {
                await client.SendErrorMessageAsync(Localization.Instance["Prompt_NoAvailableServer"]).ConfigureAwait(false);
                return;
            }

            // Already on default?
            if (client.CurrentServer is not null &&
                client.CurrentServer.Name.Equals(def.Name, StringComparison.OrdinalIgnoreCase))
            {
                await client.SendErrorMessageAsync(string.Format(Localization.Get("Command_AlreadyIn"), def.Name)).ConfigureAwait(false);
                return;
            }

            Logs.Info($"[{client.Name}] /mse back → {def.Name}");
            await client.Join(def, cancellationToken).ConfigureAwait(false);
        }


        /// <summary>
        /// Dimensions-style: open backend and pure passthrough (no PreConnect reinject).
        /// Used for first join when SwitchToDefaultServerOnJoin is true.
        /// </summary>
        public static async Task<bool> ConnectPassthroughAsync(this ClientData client, ServerInfo server, CancellationToken cancel = default)
        {
            cancel = cancel == default ? new CancellationTokenSource(Config.Instance.SwitchTimeOut).Token : cancel;
            Exception last = null;
            // Retry once — TShock often drops the very first TCP race
            for (int attempt = 1; attempt <= 2; attempt++)
            {
                try
                {
                    var ip = await Utils.ResolveAddressAsync(server.IP, cancel).ConfigureAwait(false);
                    if (ip is null)
                    {
                        Logs.Warn($"Invalid address: {server.IP}");
                        return false;
                    }
                    var tcp = new System.Net.Sockets.TcpClient();
                    await tcp.ConnectAsync(ip, server.Port, cancel).ConfigureAwait(false);
                    tcp.NoDelay = true;
                    // Brief settle so TShock accept thread is ready (fixes 2-3 reconnects)
                    await Task.Delay(50, cancel).ConfigureAwait(false);
                    var container = new DataStruct.TcpContainer(tcp);
                    await client.Adapter.SetServerConnectionAsync(container, disposeOld: true).ConfigureAwait(false);
                    client.CurrentServer = server;
                    client.State = ClientState.NewConnection;
                    Logs.Info($"[{client.Name}] passthrough connected to {server.Name} (try {attempt})");
                    return true;
                }
                catch (Exception ex)
                {
                    last = ex;
                    Logs.Warn($"Passthrough try {attempt} failed: {ex.Message}");
                    await Task.Delay(150, cancel).ConfigureAwait(false);
                }
            }
            Logs.Error($"Passthrough connect failed: {last?.Message}");
            return false;
        }

        public static void Back(this ClientData client)
            => _ = client?.BackAsync();

        public static async ValueTask SyncAsync(this ClientData client, ServerInfo targetServer, CancellationToken cancellationToken = default)
        {
            // After switch: character was already reinjected to the backend as RAW packets
            // in PreConnectHandler. Client already receives live WorldData/tiles from server.
            // Do NOT reserialize WorldData/inventory via TrProtocol — that corrupts 1.4.5 packets
            // and can desync/kick the client (Python proxy does pure passthrough here).
            _ = targetServer;
            _ = cancellationToken;
            Logs.Text($"Syncing player: [{client.Name}] (passthrough — skip reserialize)");
            client.Syncing = false;
            await ValueTask.CompletedTask.ConfigureAwait(false);
        }
        public static void Disconnect(this ClientData client, string reason = null)
            => _ = client.DisconnectAsync(reason);

        public static async ValueTask DisconnectAsync(this ClientData client, string reason = null)
        {
            if (client is null || client.Disposed)
                return;
            if (client.State == ClientState.Disconnect)
                return;
            client.State = ClientState.Disconnect;

            var text = string.IsNullOrWhiteSpace(reason) ? "Disconnected." : reason;
            if (text.Length > 180) text = text[..180];
            var display = string.IsNullOrWhiteSpace(client.Name) || client.Name.Any(c => c < 0x20)
                ? (client.IP ?? "player")
                : client.Name;
            Logs.Text($"[{display}] disconnected. {text}");
            try { Hooks.OnPlayerLeave(client, out _); } catch { }

            if (client.Adapter is { } adapter)
            {
                try
                {
                    try { adapter.PauseRouting(true, true); } catch { }

                    // Chat (visible while still connected)
                    try
                    {
                        await client.SendMessageAsync($"[c/FF5555:{text}]", Utils.MakeColor(255, 85, 85), false).ConfigureAwait(false);
                        await Task.Delay(150).ConfigureAwait(false);
                    }
                    catch { }

                    var raw = BuildRawDisconnect(text);
                    // Dimensions-style: write disconnect on the wire then half-close SEND
                    // so client shows the reason dialog (socket.end equivalent).
                    if (adapter.ClientConnection is { IsDisposed: false } cc)
                    {
                        await cc.EndWithPacketAsync((ReadOnlyMemory<byte>)raw).ConfigureAwait(false);
                        Logs.Info($"[{display}] Kick via EndWithPacket");
                    }
                    else
                    {
                        await adapter.SendToClientDirectAsync((ReadOnlyMemory<byte>)raw).ConfigureAwait(false);
                        Logs.Info($"[{display}] Kick via SendDirect fallback");
                    }

                    // Force-close after 3s if client does not leave (same as Dimensions FORCE_DISCONNECT_TIMEOUT)
                    await Task.Delay(3000).ConfigureAwait(false);
                }
                catch (Exception ex)
                {
                    Logs.Warn($"DisconnectAsync: {ex.Message}");
                }
            }
            client.Dispose();
        }

        /// <summary>Terraria packet 2 Disconnect with NetworkText Literal.</summary>
        static byte[] BuildRawDisconnect(string reason)
        {
            reason ??= "Disconnected";
            if (reason.Length > 200) reason = reason[..200];
            var msg = System.Text.Encoding.UTF8.GetBytes(reason);
            // body: type=2, mode=0 (Literal), 7-bit len, utf8
            var body = new List<byte> { 2, 0 };
            Write7Bit(body, msg.Length);
            body.AddRange(msg);
            var buf = new byte[body.Count + 2];
            System.Buffers.Binary.BinaryPrimitives.WriteUInt16LittleEndian(buf.AsSpan(0, 2), (ushort)(body.Count + 2));
            body.CopyTo(buf, 2);
            return buf;
        }
        static void Write7Bit(List<byte> dst, int value)
        {
            while (value >= 0x80)
            {
                dst.Add((byte)(value | 0x80));
                value >>= 7;
            }
            dst.Add((byte)value);
        }
    }
    public static partial class ClientManager
    {
        #region 消息函数
        public static async ValueTask<bool> SendDataToClientAsync(this ClientData client, ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            if (client is null || client.Disposed)
                return false;
            if (client.Adapter?.ClientConnection is null)
                return false;
            if (buffer.Length < 3)
                return true;

            try
            {
#if DEBUG
                var span = buffer.Span;
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine($"[Send to CLIENT] <{BitConverter.ToInt16(span)} byte>, Length: {span.Length} - {(MessageID)span[2]}");
                Console.ResetColor();
#endif
                return await client.Adapter.SendToClientDirectAsync(buffer, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logs.Warn($"Failed to send data to {client.Name}{Environment.NewLine}{ex}");
                return false;
            }
        }
        public static async ValueTask<bool> SendDataToServerAsync(this ClientData client, ReadOnlyMemory<byte> buffer, CancellationToken cancellationToken = default)
        {
            if (client is null || client.Disposed)
                return false;
            if (client.Adapter?.ServerConnection is null)
                return false;
            if (buffer.Length < 3)
                return true;

            try
            {
#if DEBUG
                var span = buffer.Span;
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine($"[Send to SERVER] <{BitConverter.ToInt16(span)} byte>, Length: {span.Length} - {(MessageID)span[2]}");
                Console.ResetColor();
#endif
                return await client.Adapter.SendToServerDirectAsync(buffer, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logs.Info($"Failed to send data to server: {client.Name}{Environment.NewLine}{ex}");
                return false;
            }
        }

        // Removed synchronous SendDataToClient/Server wrappers to avoid blocking. Prefer async APIs above.
        public static async ValueTask SendMessageAsync(this ClientData client, string text, Color color, bool withPrefix = true)
        {
            if (client is null)
            {
                Console.WriteLine(text);
                return;
            }
            if (client.Adapter is { } adapter)
            {
                var message = withPrefix ? $"{Localization.Instance["Prefix"]}{text}" : text;
                await adapter
                    .SendToClientDirectAsync(new NetTextModule
                    {
                        TextS2C = new TextS2C
                        {
                            PlayerSlot = 255,
                            Text = Utils.MakeLiteral(message),
                            Color = color,
                        }
                    })
                    .ConfigureAwait(false);
            }
        }

        public static ValueTask SendMessageAsync(this ClientData client, string text, bool withPrefix = true)
            => client.SendMessageAsync(text, Utils.MakeColor(255, 255, 255), withPrefix);

        public static ValueTask SendInfoMessageAsync(this ClientData client, string text, bool withPrefix = true)
            => client.SendMessageAsync(text, Utils.MakeColor(220, 220, 130), withPrefix);

        public static ValueTask SendSuccessMessageAsync(this ClientData client, string text, bool withPrefix = true)
            => client.SendMessageAsync(text, Utils.MakeColor(165, 230, 155), withPrefix);

        public static ValueTask SendErrorMessageAsync(this ClientData client, string text, bool withPrefix = true)
            => client.SendMessageAsync(text, Utils.MakeColor(220, 135, 135), withPrefix);
        public static void SendMessage(this ClientData client, string text, Color color, bool withPrefix = true)
            => _ = client.SendMessageAsync(text, color, withPrefix);
        public static void SendMessage(this ClientData client, string text, bool withPrefix = true) => client.SendMessage(text, Utils.MakeColor(255, 255, 255), withPrefix);
        public static void SendInfoMessage(this ClientData client, string text, bool withPrefix = true) => client.SendMessage(text, Utils.MakeColor(220, 220, 130), withPrefix);
        public static void SendSuccessMessage(this ClientData client, string text, bool withPrefix = true) => client.SendMessage(text, Utils.MakeColor(165, 230, 155), withPrefix);
        public static void SendErrorMessage(this ClientData client, string text, bool withPrefix = true) => client.SendMessage(text, Utils.MakeColor(220, 135, 135), withPrefix);
        #endregion

        #region 一些小工具
        public static async ValueTask BroadcastAsync(this ClientData client, string message, bool ignoreSelf = true)
        {
            foreach (var c in Data.Clients.Where(c => !ignoreSelf || c != client))
                await c.SendMessageAsync(message, Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
        }
        public static void Broadcast(this ClientData client, string message, bool ignoreSelf = true) => _ = client.BroadcastAsync(message, ignoreSelf);
        public static void ReadVersion(this ClientData client, ClientHello hello) => client.ReadVersion(hello.Version);
        public static void ReadVersion(this ClientData client, string version)
        {

            client.Player.VersionNum = version.StartsWith("Terraria") && int.TryParse(version[8..], out var v)
                            ? v
                            : Config.Instance.DefaultServerInternal.VersionNum;
            Logs.Info($"Version of {client.Name} is {Data.Convert(client.Player.VersionNum)}<{client.Player.VersionNum}>.");
        }
        public static ValueTask<(bool handled, bool continueSend)> HandleCommand(this ClientData client, string cmd)
        {
            return Core.Command.HandleCommand(client, cmd);
        }
        /// <summary>Drop client item-teleport packets for a few seconds after join/switch (avoids TShock permission spam without granting tshock.tp.rod).</summary>
        public static void ArmItemTeleportSuppress(this ClientData client, int ms = 8000)
        {
            if (client is null) return;
            client.SuppressItemTeleportUntil = Environment.TickCount64 + ms;
        }
        public static async ValueTask Teleport(this ClientData client, int tileX, int tileY)
        {
            await client.Adapter.SendToClientDirectAsync(new Teleport
            {
                Bit1 = new BitsByte(),
                PlayerSlot = client.Player.Index,
                Position = new Vector2(tileX * 16, tileY * 16),
                Style = 0,
                ExtraInfo = 0,
            });
        }
        public static async ValueTask AddBuffAsync(this ClientData client, ushort buffID, int time = 60)
        {
            if (client?.Adapter is { } adapter)
            {
                await adapter.SendToClientDirectAsync(new AddPlayerBuff
                {
                    OtherPlayerSlot = client.Player.Index,
                    BuffType = buffID,
                    BuffTime = time,
                }).ConfigureAwait(false);
            }
        }
        public static void AddBuff(this ClientData client, ushort buffID, int time = 60)
            => _ = client.AddBuffAsync(buffID, time);
        public static async ValueTask CreateParticalAsync(this ClientData client, ParticleOrchestraType type, ParticleOrchestraSettings? setting = null)
        {
            if (client?.Adapter is not { } adapter)
                return;

            await adapter.SendToClientDirectAsync(new NetParticlesModule
            {
                ParticleType = type,
                Setting = setting ?? new ParticleOrchestraSettings
                {
                    MovementVector = new Vector2(0, 0),
                    PositionInWorld = new Vector2(client.Player.X, client.Player.Y),
                    UniqueInfoPiece = 0,
                    IndexOfPlayerWhoInvokedThis = client.Player.Index,
                }
            }).ConfigureAwait(false);
        }
        public static void CreatePartical(this ClientData client, ParticleOrchestraType type, ParticleOrchestraSettings? setting = null)
            => _ = client.CreateParticalAsync(type, setting);
        public static void CreatePartical(this ClientData client, ParticleOrchestraType type, Vector2 position, Vector2 movement = default)
        {
            client.CreatePartical(type, new ParticleOrchestraSettings
            {
                MovementVector = movement,
                PositionInWorld = position,
                UniqueInfoPiece = 0,
                IndexOfPlayerWhoInvokedThis = client.Player.Index,
            });
        }
        #endregion

        #region 其他
        public static ClientData GetClientByName(string name) => Data.Clients.FirstOrDefault(c => c.Name == name);
        #endregion

        private static async ValueTask DispatchBatchToClientAsync(ClientData client, List<Utils.PacketMemoryRental> rentals, CancellationToken cancellationToken)
        {
            if (rentals.Count == 0)
            {
                foreach (var rental in rentals)
                    rental.Dispose();
                return;
            }

            var adapter = client.Adapter;
            if (adapter is null)
            {
                foreach (var rental in rentals)
                    rental.Dispose();
                return;
            }

            var bufferArray = new ReadOnlyMemory<byte>[rentals.Count];
            var rentalArray = new Utils.PacketMemoryRental[rentals.Count];
            for (int i = 0; i < rentals.Count; i++)
            {
                rentalArray[i] = rentals[i];
                bufferArray[i] = rentals[i].Memory;
            }

            rentals.Clear();

            try
            {
                await adapter.SendToClientBatchAsync(bufferArray, cancellationToken).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                Logs.Warn($"Failed to send batch data to {client.Name}{Environment.NewLine}{ex}");
            }
            finally
            {
                foreach (var rental in rentalArray)
                    rental.Dispose();
            }
        }
    }
}
