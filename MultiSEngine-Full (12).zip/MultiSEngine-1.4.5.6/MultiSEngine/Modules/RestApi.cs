using System.Net;
using MultiSEngine.DataStruct;
using System.Text;
using System.Text.Json;

namespace MultiSEngine.Modules
{
    /// <summary>
    /// Simple REST for Terraria server lists: GET /v2/server/status
    /// </summary>
    public static class RestApi
    {
        private static HttpListener? _listener;
        private static CancellationTokenSource? _cts;
        private static DateTime _start = DateTime.UtcNow;

        [AutoInit(postMsg: "REST API ready.")]
        public static void Init()
        {
            if (!Config.Instance.EnableRestApi)
            {
                Logs.Info("REST API disabled.");
                return;
            }
            try
            {
                _cts = new CancellationTokenSource();
                _listener = new HttpListener();
                var prefix = $"http://*:{Config.Instance.RestPort}/";
                _listener.Prefixes.Add(prefix);
                _listener.Start();
                _start = DateTime.UtcNow;
                Logs.Info($"REST http://0.0.0.0:{Config.Instance.RestPort}/v2/server/status");
                _ = Task.Run(() => Loop(_cts.Token));
            }
            catch (Exception ex)
            {
                Logs.Warn($"REST failed to start (try run as admin or use localhost): {ex.Message}");
                try
                {
                    _listener = new HttpListener();
                    _listener.Prefixes.Add($"http://127.0.0.1:{Config.Instance.RestPort}/");
                    _listener.Start();
                    _ = Task.Run(() => Loop(_cts!.Token));
                    Logs.Info($"REST http://127.0.0.1:{Config.Instance.RestPort}/v2/server/status");
                }
                catch (Exception ex2)
                {
                    Logs.Warn($"REST disabled: {ex2.Message}");
                }
            }
        }

        static async Task Loop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested && _listener is { IsListening: true })
            {
                HttpListenerContext ctx;
                try { ctx = await _listener.GetContextAsync().ConfigureAwait(false); }
                catch { break; }
                _ = Task.Run(() => Handle(ctx));
            }
        }

        static void Handle(HttpListenerContext ctx)
        {
            try
            {
                var path = ctx.Request.Url?.AbsolutePath ?? "";
                if (path.Contains("/v2/server/status") || path.Contains("/v2/status") || path == "/" || path == "")
                {
                    var players = Data.Clients.Where(c => !c.Disposed && !string.IsNullOrEmpty(c.Name)).Select(c => c.Name).ToList();
                    var up = DateTime.UtcNow - _start;
                    var body = JsonSerializer.Serialize(new
                    {
                        status = "200",
                        name = Config.Instance.RestName ?? Config.Instance.ServerName,
                        serverversion = "1.4.5.6",
                        tshockversion = "6.1.0.0",
                        port = Config.Instance.ListenPort,
                        playercount = players.Count,
                        maxplayers = Config.Instance.RestMaxPlayers,
                        world = Config.Instance.RestWorld ?? "MultiSEngine",
                        uptime = $"{(int)up.TotalDays}.{up.Hours:D2}:{up.Minutes:D2}:{up.Seconds:D2}",
                        serverpassword = false,
                        players
                    });
                    var buf = Encoding.UTF8.GetBytes(body);
                    ctx.Response.StatusCode = 200;
                    ctx.Response.ContentType = "application/json; charset=utf-8";
                    ctx.Response.Headers.Add("Access-Control-Allow-Origin", "*");
                    ctx.Response.ContentLength64 = buf.Length;
                    ctx.Response.OutputStream.Write(buf, 0, buf.Length);
                }
                else
                {
                    ctx.Response.StatusCode = 404;
                }
            }
            catch { }
            finally
            {
                try { ctx.Response.Close(); } catch { }
            }
        }
    }
}
