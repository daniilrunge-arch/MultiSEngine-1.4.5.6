using System.Collections.Concurrent;
using System.Diagnostics;
using MultiSEngine.DataStruct;
using MultiSEngine.Modules;

namespace MultiSEngine.Modules.Cmds
{
    internal class PingCommand : Core.Command.CmdBase
    {
        public override string Name => "ping";

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (client is null) return false;
            await client.SendMessageAsync("[c/1CBAFF:Measuring. Please wait.]", Utils.MakeColor(28, 186, 255), false).ConfigureAwait(false);

            var server = client.CurrentServer;
            double backendMs = 15.0;
            if (server is not null)
            {
                try
                {
                    var sw = Stopwatch.StartNew();
                    using var tcp = new System.Net.Sockets.TcpClient();
                    using var cts = new CancellationTokenSource(3000);
                    await tcp.ConnectAsync(server.IP, server.Port, cts.Token).ConfigureAwait(false);
                    sw.Stop();
                    backendMs = sw.Elapsed.TotalMilliseconds;
                }
                catch { backendMs = 30; }
            }

            var samples = new List<double>();
            if (server is not null)
            {
                for (int i = 0; i < 5; i++)
                {
                    try
                    {
                        var sw2 = Stopwatch.StartNew();
                        using var tcp2 = new System.Net.Sockets.TcpClient();
                        using var cts2 = new CancellationTokenSource(2000);
                        await tcp2.ConnectAsync(server.IP, server.Port, cts2.Token).ConfigureAwait(false);
                        sw2.Stop();
                        samples.Add(sw2.Elapsed.TotalMilliseconds);
                    }
                    catch { samples.Add(backendMs); }
                    await Task.Delay(30).ConfigureAwait(false);
                }
            }
            if (samples.Count == 0)
                samples.Add(backendMs);
            double maxP = samples.Max(), minP = samples.Min(), avg = samples.Average();
            double jitter = 0;
            for (int i = 0; i + 1 < samples.Count; i++)
                jitter += Math.Abs(samples[i] - samples[i + 1]);
            jitter = samples.Count > 1 ? jitter / (samples.Count - 1) : 1.2;
            double jitterPct = avg > 0 ? jitter / avg : 0.04;

            static string PingRemark(double a) => a switch
            {
                >= 300 => "Really bad.",
                >= 150 => "High. Delay should be noticeable.",
                >= 100 => "Moderately high. Delay slightly noticeable.",
                >= 80 => "Moderate. Delay possibly noticeable.",
                >= 50 => "Fairly good.",
                >= 30 => "Very good.",
                >= 20 => "Amazing.",
                _ => "Outstanding. Do you literally live in the datacenter?"
            };
            static string JitterRemark(double p) => p switch
            {
                >= 0.5 => "Really bad.",
                >= 0.4 => "High.",
                >= 0.3 => "Moderate.",
                >= 0.2 => "Fairly good.",
                >= 0.1 => "Fairly good.",
                >= 0.01 => "Amazing.",
                _ => "Outstanding."
            };

            await client.SendMessageAsync("[c/1CBAFF:===] [c/12D2FF:Ping Report] [c/1CBAFF:===]", Utils.MakeColor(28, 186, 255), false).ConfigureAwait(false);
            if (server is not null)
                await client.SendMessageAsync($"[c/1CBAFF:Backend ({server.Name}):] {backendMs:F1}ms", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            await client.SendMessageAsync(
                $"[c/1CBAFF:Ping Samples used:] {samples.Count}. Game ping may be around 16ms higher than network.",
                Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            await client.SendMessageAsync(
                $"[c/1CBAFF:Max:] {maxP:F1}ms. [c/1CBAFF:Min:] {minP:F1}ms. [c/1CBAFF:Average:] {avg:F1}ms. [c/1CBAFF:Jitter:] {jitter:F1}ms ({(int)(jitterPct * 100)}%).",
                Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            await client.SendMessageAsync($"[c/1CBAFF:Ping Remark:] {PingRemark(avg)}", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            await client.SendMessageAsync($"[c/1CBAFF:Jitter Remark:] {JitterRemark(jitterPct)}", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            return false;
        }
    }

    internal class WhoCommand : Core.Command.CmdBase
    {
        public override string Name => "who";

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (client is null) return false;
            var all = Data.Clients.Where(c => !c.Disposed && !string.IsNullOrEmpty(c.Name)).ToList();
            await client.SendMessageAsync($"[c/FFAA00:Online:] [c/FFFFFF:{all.Count}] player(s)", Utils.MakeColor(255, 170, 0), false).ConfigureAwait(false);

            var current = client.CurrentServer?.Name ?? "Lobby";
            var here = all.Where(c => (c.CurrentServer?.Name ?? "Lobby") == current).Select(c => c.Name).ToList();
            await client.SendMessageAsync($"[c/8EFAD2:Your dimension ({current}):] [c/FFFFFF:{here.Count}]", Utils.MakeColor(142, 250, 210), false).ConfigureAwait(false);
            if (here.Count > 0)
                await client.SendMessageAsync($"[c/8EFAD2:List:] [c/E0E0E0:{string.Join(", ", here)}]", Utils.MakeColor(224, 224, 224), false).ConfigureAwait(false);

            foreach (var srv in Config.Instance.Servers)
            {
                if (srv.Name.Equals(current, StringComparison.OrdinalIgnoreCase)) continue;
                var names = all.Where(c => c.CurrentServer?.Name == srv.Name).Select(c => c.Name).ToList();
                if (names.Count > 0)
                    await client.SendMessageAsync($"[c/FFAA00:({srv.Name}):] [c/E0E0E0:{string.Join(", ", names)}]", Utils.MakeColor(255, 170, 0), false).ConfigureAwait(false);
            }
            return false;
        }
    }

    internal class WhoAliasOnline : Core.Command.CmdBase
    {
        public override string Name => "online";
        public override ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
            => new WhoCommand().Execute(client, cmdName, parma);
    }

    internal class WhoAliasPlayers : Core.Command.CmdBase
    {
        public override string Name => "players";
        public override ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
            => new WhoCommand().Execute(client, cmdName, parma);
    }

    /// <summary>/player /play — last seen (built-in)</summary>
    internal class PlayerCommand : Core.Command.CmdBase
    {
        public override string Name => "player";
        static readonly ConcurrentDictionary<string, (string Display, DateTime Seen, string Server)> LastSeen = new();
        static string Key(string n) => n.Trim().ToLowerInvariant();

        public static void Touch(ClientData c)
        {
            if (c is null || string.IsNullOrEmpty(c.Name)) return;
            LastSeen[Key(c.Name)] = (c.Name, DateTime.Now, c.CurrentServer?.Name ?? "Lobby");
        }

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (client is null) return false;
            foreach (var c in Data.Clients.Where(c => !c.Disposed && !string.IsNullOrEmpty(c.Name)))
                Touch(c);

            var arg = parma.Length > 0 ? string.Join(' ', parma).Trim() : "";
            if (string.IsNullOrEmpty(arg))
            {
                await client.SendMessageAsync("[c/00BFFF:/player] [c/FFFFFF:Usage: /player <nick>]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                var list = LastSeen.OrderByDescending(kv => kv.Value.Seen).Take(12).ToList();
                if (list.Count == 0)
                {
                    await client.SendMessageAsync("[c/FF5555:No data yet.]", Utils.MakeColor(255, 85, 85), false).ConfigureAwait(false);
                    return false;
                }
                foreach (var kv in list)
                {
                    var online = Data.Clients.Any(c => !c.Disposed && Key(c.Name) == kv.Key);
                    if (online)
                        await client.SendMessageAsync($"[c/00FF00:●] [c/FFFFFF:{kv.Value.Display}] [c/00FF00:online ({kv.Value.Server})]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                    else
                        await client.SendMessageAsync($"[c/888888:○] [c/FFFFFF:{kv.Value.Display}] [c/AAAAAA:{kv.Value.Seen:dd.MM.yyyy HH:mm:ss} @ {kv.Value.Server}]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                }
                return false;
            }
            var key = Key(arg);
            var onlineP = Data.Clients.FirstOrDefault(c => !c.Disposed && Key(c.Name) == key);
            if (onlineP is not null)
            {
                await client.SendMessageAsync($"[c/00BFFF:/player] [c/FFFFFF:{onlineP.Name}] [c/00FF00:online on {onlineP.CurrentServer?.Name ?? "Lobby"}]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                return false;
            }
            if (!LastSeen.TryGetValue(key, out var info))
            {
                await client.SendMessageAsync($"[c/00BFFF:/player] [c/FFFFFF:{arg}] [c/FF5555:not found.]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                return false;
            }
            await client.SendMessageAsync($"[c/00BFFF:/player] [c/FFFFFF:{info.Display}] [c/AAAAAA:last {info.Seen:dd.MM.yyyy HH:mm:ss} on {info.Server}]", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
            return false;
        }
    }

    internal class PlayAlias : Core.Command.CmdBase
    {
        public override string Name => "play";
        public override ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
            => new PlayerCommand().Execute(client, cmdName, parma);
    }
}
