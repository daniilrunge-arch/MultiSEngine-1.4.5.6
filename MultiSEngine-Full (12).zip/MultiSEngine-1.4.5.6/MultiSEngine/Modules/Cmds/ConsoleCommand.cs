using MultiSEngine.DataStruct;

namespace MultiSEngine.Modules.Cmds
{
    internal class ConsoleCommand : Core.Command.CmdBase
    {
        public override string Name => "";
        public override bool ServerCommand => true;
        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (string.IsNullOrEmpty(cmdName))
                return true;
            var internalCommand = Data.Commands.FirstOrDefault(c => c.Name == "mse");
            switch (cmdName)
            {
                case "l":
                case "list":
                    {
                        if (parma.Length >= 1)
                        {
                            var sn = parma[0];
                            var srv = Utils.GetSingleServerInfoByName(sn) ?? Config.Instance.Servers.FirstOrDefault(s => s.Name.Equals(sn, StringComparison.OrdinalIgnoreCase) || (s.ShortName?.Equals(sn, StringComparison.OrdinalIgnoreCase) ?? false));
                            if (srv is null)
                            {
                                Logs.Error($"Server '{sn}' not found.");
                                break;
                            }
                            var players = Data.Clients.Where(c => !c.Disposed && c.CurrentServer?.Name == srv.Name).ToList();
                            Logs.Info($"[{srv.Name}] {players.Count} player(s): {(players.Count == 0 ? "(none)" : string.Join(", ", players.Select(p => p.Name)))}", false);
                        }
                        else
                        {
                            foreach (var server in Config.Instance.Servers)
                            {
                                var players = Data.Clients.Where(c => !c.Disposed && c.CurrentServer?.Name == server.Name).ToList();
                                Logs.Info($"- {server.Name} [{server.IP}:{server.Port}] <{players.Count}> {(players.Count == 0 ? "" : ": " + string.Join(", ", players.Select(p => p.Name)))}", false);
                            }
                        }
                        break;
                    }
                case "ol":
                case "online":
                case "playing":
                    Logs.Info($"{Data.Clients.Count} Player(s) Online:{Environment.NewLine}{string.Join(", ", from c in Data.Clients let text = $"{c.Name} <{c.CurrentServer?.Name ?? "FakeWorld"}>" select text)}", false);
                    break;
                case "stop":
                case "exit":
                    return false;
                case "k":
                case "kick":
                    if (parma.Any())
                    {
                        var name = parma[0].Trim().ToLower();
                        if (Data.Clients.FirstOrDefault(c => c.Name.ToLower() == name || c.Name.ToLower().StartsWith(name)) is { } c)
                        {
                            var why = parma.Length > 1 ? string.Join(" ", parma.Skip(1)) : "Kicked by admin";
                            await c.DisconnectAsync($"You were kicked from {Config.Instance.ServerName}: {why}");
                        }
                        else
                            Logs.Error($"Specified player: [{parma[0]}] not found.");
                    }
                    else
                        Logs.Error(Localization.Instance["Prompt_InvalidFormat"]);
                    break;
                case "rl":
                case "reload":
                    Config.Reload();
                    Localization._instance = null;
                    Logs.Success("Successfully reloaded.");
                    break;
                case "reloadplugin":
                case "rp":
                    Core.PluginSystem.Reload();
                    break;
                case "broadcast":
                case "bc":
                    if (parma.Length > 1)
                    {
                        if (Utils.GetServersInfoByName(parma[1]).FirstOrDefault() is { } server)
                        {
                            foreach (var c in Data.Clients.Where(c => c.CurrentServer == server))
                                await c.SendMessageAsync($"[Broadcast] {parma[0]}", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                        }
                        else
                            Logs.Error(string.Format(Localization.Get("Command_ServerNotFound"), parma[1]));
                    }
                    else
                    {
                        foreach (var c in Data.Clients)
                            await c.SendMessageAsync($"[Broadcast] {parma.FirstOrDefault()}", Utils.MakeColor(255, 255, 255), false).ConfigureAwait(false);
                    }
                    Logs.Info($"Broadcast: {(parma.Length > 1 ? parma[1] : parma[0])}");
                    break;
                case "t":
                case "test":
                    if (parma.Any())
                    {
                        bool showDetail = parma.Length > 1 && parma[1].ToLower() == "-detail";
                        if (parma[0].ToLower() == "all")
                            await Core.Net.TestAllAsync(showDetail).ConfigureAwait(false);
                        else if (Utils.GetSingleServerInfoByName(parma[0]) is { } testServer)
                            await Core.Net.TestConnectAsync(testServer, showDetail).ConfigureAwait(false);
                        else
                            Logs.Error($"The server named [{parma[0]}] was not found");
                    }
                    else
                        Logs.Error(Localization.Instance["Prompt_InvalidFormat"]);
                    break;
                case "help":
                default:
                    Logs.Info($"Avaliable console commands:{Environment.NewLine}" +
                        $"- stop(exit) -- Exit MultiSEngine.{Environment.NewLine}" +
                        $"- kick(k) <Player name> (reason) -- Kick out the specified player.{Environment.NewLine}" +
                        $"- broadcase(bc) (target server) <message>  -- Send a message to all players.{Environment.NewLine}" +
                        $"- list(l) -- List all servers in the config.{Environment.NewLine}" +
                        $"- online(ol) -- List all online players.{Environment.NewLine}" +
                        $"- test(t) <Server name>/<all> (-detail) -- Test if the server can connect. If you add the detail parameter at the end, it will show the details of the connection{Environment.NewLine}" +
                        $"- reload(rl) -- Overloading most of the config file content.{Environment.NewLine}" +
                        $"- reloadplugin(rp) -- Reload Plugin.{Environment.NewLine}", false);
                    break;
            }
            Data.Commands.FirstOrDefault(c => c.Name == "mce")?.Execute(client, cmdName, parma);
            return true;
        }
    }
}
