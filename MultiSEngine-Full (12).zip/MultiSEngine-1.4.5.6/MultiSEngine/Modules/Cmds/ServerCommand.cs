using MultiSEngine.DataStruct;

namespace MultiSEngine.Modules.Cmds
{
    /// <summary>
    /// /server Server2  and  /s Server2  — switch dimension (same as /mse tp)
    /// </summary>
    internal class ServerCommand : Core.Command.CmdBase
    {
        public override string Name => "server";

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (client is null) return false;
            if (parma.Length < 1)
            {
                await client.SendInfoMessageAsync("Usage: /server <name>  |  /s <name>  |  /mse list").ConfigureAwait(false);
                return false;
            }
            var serverName = parma[0];
            if (client.State > ClientState.ReadyToSwitch && client.State < ClientState.InGame)
            {
                await client.SendErrorMessageAsync(Localization.Get("Command_IsSwitching")).ConfigureAwait(false);
                return false;
            }
            if (Utils.GetServersInfoByName(serverName).FirstOrDefault() is { } server)
            {
                if (client.CurrentServer == server)
                    await client.SendErrorMessageAsync(string.Format(Localization.Get("Command_AlreadyIn"), server.Name)).ConfigureAwait(false);
                else
                {
                    await client.SendInfoMessageAsync(string.Format(Localization.Get("Command_Switch"), server.Name)).ConfigureAwait(false);
                    await client.Join(server).ConfigureAwait(false);
                }
            }
            else
                await client.SendErrorMessageAsync(string.Format(Localization.Get("Command_ServerNotFound"), serverName)).ConfigureAwait(false);
            return false;
        }
    }

    internal class ServerShortCommand : Core.Command.CmdBase
    {
        public override string Name => "s";

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            // reuse ServerCommand logic
            return await new ServerCommand().Execute(client, cmdName, parma).ConfigureAwait(false);
        }
    }

    internal class ListServersCommand : Core.Command.CmdBase
    {
        public override string Name => "list";

        public override async ValueTask<bool> Execute(ClientData client, string cmdName, string[] parma)
        {
            if (client is null) return false;
            var lines = Config.Instance.Servers.Select(server =>
                $"{server.Name} {(string.IsNullOrEmpty(server.ShortName) ? "" : $"[{server.ShortName}]")} <{server.Online().Length}>");
            await client.SendSuccessMessageAsync($"{Localization.Get("Command_AviliableServer")}{Environment.NewLine + "- "}{string.Join(Environment.NewLine + "- ", lines)}").ConfigureAwait(false);
            return false;
        }
    }
}
