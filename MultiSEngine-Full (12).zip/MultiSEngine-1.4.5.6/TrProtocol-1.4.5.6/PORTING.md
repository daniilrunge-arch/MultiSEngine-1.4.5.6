# Porting MultiSEngine to new TrProtocol (1.4.5.6)

New TrProtocol is NOT drop-in compatible.

| Old | New |
|-----|-----|
| `TrProtocol.Packets` | `TrProtocol.NetPackets` |
| `TrProtocol.Packets.Modules` | `TrProtocol.NetPackets.Modules` |
| `class Packet` | `interface INetPacket` / `partial struct` |
| `PacketSerializer(bool, string version)` | `PacketSerializer(bool client)` |
| `pkt as SyncPlayer` | `pkt is SyncPlayer sp` (structs!) |
| SyncPlayer without voice | + VoiceVariant, VoicePitchOffset |
| SyncEquipment without Details | + SyncEquipmentDetails |

## Required work (estimate: large)

1. Change global usings in .csproj
2. Rewrite Utils.cs serializer wrappers
3. Replace every `Packet` type with `INetPacket`
4. Replace all `as PacketType` casts with pattern matching for structs
5. Update Color/Vector2 imports (Microsoft.Xna.Framework)
6. Rebuild against TrProtocol.dll from this folder

Until then, MultiSEngine uses the compatible old DLL + raw packet passthrough
which is what the LIVEFWD build ships with.
