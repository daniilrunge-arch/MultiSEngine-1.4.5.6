@echo off
chcp 65001 >nul
echo Building self-contained MultiSEngine (Windows x64)...
dotnet publish MultiSEngine\MultiSEngine.csproj -c Release -r win-x64 --self-contained true -o publish-win
if errorlevel 1 (
  echo BUILD FAILED
  pause
  exit /b 1
)
copy /Y Config.json publish-win\Config.json >nul 2>&1
copy /Y MOTD.txt publish-win\MOTD.txt >nul 2>&1
if not exist publish-win\Plugins mkdir publish-win\Plugins
copy /Y Plugins\anticheat.json publish-win\Plugins\anticheat.json >nul 2>&1
echo.
echo OK: publish-win\
echo Run MultiSEngine.exe from that folder (no .NET install needed on server).
pause
