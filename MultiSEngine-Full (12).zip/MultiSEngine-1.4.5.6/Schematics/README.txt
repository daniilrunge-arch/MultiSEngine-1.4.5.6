LOBBY SCHEMATIC (TEdit)
=======================
File: Lobbyshem.TEditSch

MultiSEngine FakeWorld cannot load TEdit binary format directly
(would need full tile protocol encoder for 1.4.5.x).

How to use this lobby build:
1. Open your LOBBY Terraria world in TEdit.
2. Import / paste Lobbyshem.TEditSch into the world.
3. Save world, point TShock Server1 at that world.
4. In MultiSEngine Config.json either:
   - SwitchToDefaultServerOnJoin: true  → players land on lobby world immediately
   - or false → FakeWorld platform, then /mse tp Server1

FakeWorld remains a simple empty platform (spawn square) for waiting.
