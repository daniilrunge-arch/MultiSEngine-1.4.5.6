#!/bin/bash
set -e
echo "Building self-contained MultiSEngine (win-x64)..."
dotnet publish MultiSEngine/MultiSEngine.csproj -c Release -r win-x64 --self-contained true -o publish-win
echo "OK: publish-win/"
